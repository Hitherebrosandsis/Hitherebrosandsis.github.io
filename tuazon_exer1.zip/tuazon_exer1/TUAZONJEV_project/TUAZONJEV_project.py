#Jan Edrian Tuazon
#G - 6L
#This program serves as the project for CMSC 12. This is for logging in the history of a plant.
logdic = {} #The dictionaries
plantsdic = {}
fertdic = {}

alevalue = "" #The variable to be used in addlogentry() to know what function the program just used

Plant_ID = 1 #Id variables, they will increment to assign unique ids to various inputs
Log_ID = 1
Fertilizer_ID = 1

Plant_Name = ""#for the plants
Plant_Storage = ""
Plant_Nourishment = {}

Fertilizer_Name = ""#for the fertilizers
Stock_Amount = 0
Last_Supplier = ""

deleted = [] #for delete plant add log entry

plantslist = []#for nourishplant add log entry
fertlist = []

def addplant():
    global Plant_ID#calling the variables
    global alevalue
    global Plant_Name
    global Plant_Storage
    global Plant_Nourishment
    global plantsdic
    
    Plant_Name = input("What is the name of the plant?: ")#input plant name
    
    while True:
        Plant_Storage = input("\nWhere should we store it?(Indoor/Outdoor): ")#input storage
        if Plant_Storage.lower() == "indoor":#limiting to only allowed inputs are indoor or outdoor
           Plant_Storage = "INDOOR"
           break
        elif Plant_Storage.lower() == "outdoor":
            Plant_Storage = "OUTDOOR"
            break
        else:
            print("Invalid input!")
    
    Plant_Nourishment = {}
    while True:
        while True:#inputting fertilizers needed by the plant inputted
            x = input("\nWhat is the name of the fertilizer?(Use only alphabet characters)(Also spaced texts will turn into 1 word): ")
            x = x.replace(" ", "")#taking away the spaces
            it_is_not_alphabet = False#checking if the text contains numerical characters
            popnum = 0
            for c in x:
                if c.isalpha() == False:
                    it_is_not_alphabet = True
               
            if it_is_not_alphabet == False:
                x = x.lower()
                if Plant_Nourishment != {}:
                    for a in Plant_Nourishment.keys():
                        if x == a:
                            popnum += 1
                if popnum == 0:
                    break
                else:
                    print('Fertilizer is existing!!')
            else:
                print('Invalid Input')

        while True:
            y = input("\nHow much this fertilizer does this plant need currently?: ")#@
            can_be_float = True#checking if float-able
            radix = 0
            for i in y:
               if i.isdigit() == False:
                   if i == ".":
                       if radix == 0:
                           radix = 1
                       else:
                           can_be_float = False
                   else:
                       can_be_float = False
            if can_be_float == True:
                y = float(y)
                break
            else:
                print('Invalid Input!!!')

        Plant_Nourishment[x] = y
        
        print("\nIs that all the plant needs?(Type 'x' if it does, otherwise type other stuff): ")#the exit function of this function
        isitexit = input()
        if isitexit.lower() == "x":
            break

    plantsdic["P" + str(Plant_ID)] = [Plant_Name, Plant_Storage, Plant_Nourishment]
    
    alevalue = "addplant"#setting the format of the add log entry input
    addlogentry()
    Plant_ID += 1

def deleteplant():
    global plantsdic
    global alevalue
    global deleted
    print("Existing plants: ")
    for i, j in plantsdic.items():
        print("* " + i)
        print("    " + j[0])
        print("    " + j[1])
        print("    " + str(j[2]))
    print()
    popnum = 0
    x = input("\nWhat Plant ID should you want to delete along with its contents?: ")#@
    for k in plantsdic.keys():
        if k == x: #plant id is unique, so only one will be deleted
            deleted = k
            popnum += 1
    if popnum == 0:
        print("Plant ID not found...")
    else:
        plantsdic.pop(deleted)
        print("Successfully deleted " + deleted)
    
    alevalue = "deleteplant"
    addlogentry()

def viewplant():#need ui#good
    global plantsdic

    print('Existing Plant Names:')

    for i, j in plantsdic.items():#ui
        print("    " + j[0])
    print()

    k = input("What is the name of the plant?: ")#@

    popnum = 0
    for x, y in plantsdic.items():#showing the details of the plants with the same name as the input
        if k == y[0]:
            print("Plant Name:", y[0])
            print("Plant ID:", x)
            print("Plant Storage:", y[1])
            print("\nPlant Nourishment:")
            for m, n in y[2].items():
                print(m + ":" + str(n))
                popnum += 1
    
    if popnum == 0:
        print("Plant name not found...")

def editplant():
    global plantsdic
    print("Existing plants: ")
    for i, j in plantsdic.items():
        print("* " + i)
        print("    " + j[0])
        print("    " + j[1])
    print()
    k = input("What is the id of the plant you want to change the name and storage of?: ")#@
    if k in plantsdic:#identical code as at the add plant
        m = input("\nWhat is the new name of the plant?: ")#@
        plantsdic[k][0] = m
        while True:
            n = input("\nWhat is the new storage of the new plant?(Indoor/Outdoor): ") # @
            if n.lower() == "indoor":
                plantsdic[k][1] = "INDOOR"
                break
            elif n.lower() == "outdoor":
                plantsdic[k][1] = "OUTDOOR"
                break
            else:
                print("Invalid input!")
    else:
        print("Plant ID not found...")

def updatenourishment():
    global plantsdic
    print("Existing Plant IDs:")
    for i, j in plantsdic.items():
        print("* " + i)
        print("    " + j[0])
        print("    " + j[1])
    print()
    k = input("What is the id of the plant you want to change the nourishment needed: ")#@
    if k in plantsdic:#either appending a new fertilizer or changing the value of an existing one
        m = input("\nWhat is the fertilizer needed by this specific plant currently?: ")#@
        while True:#same floatchecker used like on the add_plant
           x = input("\nHow much this fertilizer does this plant need currently?: ")#@
           can_be_float = True
           radix = 0
           for i in x:
               if i.isdigit() == False:
                   if i == ".":
                        if radix == 0:
                           radix = 1
                        else:
                           can_be_float = False
                           print('Invalid Input!!!')
                   else:
                       can_be_float = False
                       print('Invalid Input!!!')
        
           if can_be_float == True:
                x = float(x)
                plantsdic[k][2][m] = x
                break
    

    else:
        print("Plant ID not found...")

def nourishplant():#ui#good#fix the something, summing up ferts
    global plantsdic
    global alevalue
    global fertdic
    global plantslist
    global fertlist
    
    alevaluetrue = True
    plantslist = []
    fertlist = []
    fertplant = {}
    popnum = 0
    os = 0
    k = input("What is the name of the plant?: ")#@

    for x, y in plantsdic.items():#checking if there are plants with that name existing#totaling the amount of fertilizer needed
       if k == y[0]:
           print("Plant Name:", y[0])
           print("Plant ID:", x)
           print("\nPlant Nourishment:")
           for m, n in y[2].items():
               print(m + ' ; ' + str(n))
               for i, j in fertdic.items():
                   if j[0] == m:
                       if m in fertplant.keys():
                           fertplant[m] += n
                       else:
                           fertplant[m] = n
           print()
           popnum += 1

    if popnum != 0:#also checking if it should continue on nourishing the plants
        for o in fertplant.keys():
            for p, q in fertdic.items():
                if o == q[0]:
                    os += 1
                    if fertplant[o] > q[1]:
                        alevaluetrue = False
    else:
        alevaluetrue = False
    
    if os == 0:
        alevaluetrue = False
        
    if alevaluetrue == True:#the actual nourishing
        for r in fertplant.keys():
            for s, t in fertdic.items():
                if r == t[0]:
                    t[1] = t[1] - fertplant[r]

        for e, f in plantsdic.items():
            for a, b in f[2].items():
                for c, d in fertdic.items():
                    if a == d[0]:
                        if e not in plantslist:
                            plantslist.append(e)
                        if c not in fertlist:
                            fertlist.append(c)

        alevalue = 'nourish'
        addlogentry()
    else:
        print('Error!!!')

      
########################################################################################################################

def purchasefertilizer():
    global Fertilizer_ID
    global alevalue
    global Fertilizer_Name
    global Stock_Amount
    global Last_Supplier
    global fertdic
    thefertisthere = False

    while True:
        Fertilizer_Name = input("What is the name of the fertilizer purchased?(Use only alphabet characters)(Also spaced texts will turn into 1 word): ")#@
        Fertilizer_Name = Fertilizer_Name.replace(" ", "")#same format as on the addplant where it checks if it is purely alphabet characters
        it_is_not_alphabet = False
        for c in Fertilizer_Name:
            if c.isalpha() == False:
                it_is_not_alphabet = True

        if it_is_not_alphabet == False:
            Fertilizer_Name = Fertilizer_Name.lower()
            break
        else:
            print("Invalid Input!!")
    while True:
        Stock_Amount = input("How much of the fertilizer is bought?: ")#same floatchecker
        can_be_float = True
        radix = 0
        for i in Stock_Amount:
            if i.isdigit() == False:
                if i == ".":
                    if radix == 0:
                        radix = 1
                    else:
                        can_be_float = False
                else:
                    can_be_float = False
        
        if can_be_float == True:
            Stock_Amount = float(Stock_Amount)
            break
        else:
            print('Invalid Input!!!')
    Last_Supplier = input("What is the name of the supplier of the purchased fertilizer?: ")#@
    if fertdic != {}:
        for k, l in fertdic.items():
            if l[0] == Fertilizer_Name:#the thefertisthere schtick is about knowing if the fertilizer is existing in the dictionary
                fertdic[k] = [Fertilizer_Name, l[1] + Stock_Amount, Last_Supplier]
                alevalue = "purchase"
                addlogentry()
                thefertisthere = True
                break
    if thefertisthere == False:
        fertdic["F" + str(Fertilizer_ID)] = [Fertilizer_Name, Stock_Amount, Last_Supplier]
        alevalue = "purchase"
        addlogentry()
        Fertilizer_ID += 1
        


def viewfertilizer():#need ui#good
    global fertdic

    print('Fertilizer Names:')
    for i, j in fertdic.items():
        print("    " + j[0])
    print()

    k = input("What is the name of the fertilizer?: ")#@
    popnum = 0
    for x, y in fertdic.items():#same as viewplant
        if k == y[0]:
            print("Fertilizer Name:", y[0])
            print("Fertilizer ID:", x)
            print("Stock_Amount:", y[1])
            print("Last_Supplier:", y[2], '\n')
            popnum += 1

    if popnum == 0:
        print("Fertilizer not found...")

def viewallfertilizers():#very simple, uses for loop to print everything inside the dictionary
    global fertdic
    for x, y in fertdic.items():
        print("Fertilizer Name:", y[0])
        print("     Fertilizer ID:", x)
        print("     Stock_Amount:", y[1])
        print("     Last_Supplier:", y[2], "\n")

def view_affected_plants():
    global plantsdic
    global fertdic
    print("Existing Fertilizer IDs:")
    for i, j in fertdic.items():
        print("*" + i)
        print("    " + j[0])
    print()
    k = input("What is the id of the fertilizer?: ")#@
    popnum = 0
    plants_included = []
    for x, y in fertdic.items():
        if k == x:
            print("Fertilizer Name:", y[0])
            print("Stock_Amount:", y[1])
            print("Last_Supplier:", y[2])
            popnum += 1
            for a, b in plantsdic.items():
                for u in b[2].keys():
                    if u == y[0]:
                        plants_included.append(b[0])#appending the names of plants that have that specific fertilizer
    if popnum == 0:
        print('Fertilizer ID not found...')
    else:
        print('Plants needing this fertilizer:')
        for i in plants_included:
            print('_' + i)
#######################################################################################################################

def addlogentry():
    global Log_ID
    global logdic
    global deleted
    global Plant_ID
    global Fertilizer_ID
    global alevalue
    global plantslist
    global fertlist
    x = input('What is the date today?: ')

    if alevalue == "addplant":#the values are assigned way back at the functions which came here immediately to be used
        logdic["L" + str(Log_ID)] = [str(Plant_ID), "NA", str(x), "add_plant"]

    if alevalue == "deleteplant":
        logdic["L" + str(Log_ID)] = [str(deleted), "NA", str(x), "delete_plant"]
	
    if alevalue == "purchase":
        logdic["L" + str(Log_ID)] = ["NA", str(Fertilizer_ID), str(x), "purchase"]
    
    if alevalue == "nourish":
        logdic["L" + str(Log_ID)] = [str(plantslist), str(fertlist), str(x), "nourish"]

    Log_ID += 1
		
def viewallentries():#same as view all fertilizers
    global logdic
    for x, y in logdic.items():
        print("Logbook ID:", x)
        print("     Plant ID/s:", y[0])
        print("     Fertilizer ID/s:", y[1])
        print("     Date:", y[2])
        print("     Action:", y[3])
        
def viewtransactionsperaction():#if userinput is equal to the function value of the specific log, that log will print
    global logdic
    print('Actions existing:')
    print('*      add_plant')
    print('*      delete_plant')
    print('*      purchase')
    print('*      nourish')
    print()
    k = input("What is the action you want to see the history of?: ")#@
    popnum = 0
    for x, y in logdic.items():
        if k == y[3]:
            print("Logbook ID:", x)
            print("     Plant ID:", y[0])
            print("     Fertilizer ID:", y[1])
            print("     Date:", y[2])
            popnum += 1

    if popnum == 0:
        print("History not found...")

def datareset():
    global logdic
    global fertdic
    global plantsdic
    global Fertilizer_ID
    global Plant_ID
    global Log_ID

    logdic = {}#sets the to an empty dictionary
    fertdic = {}
    plantsdic = {}
    logbook = open('logbook', 'w')#it works because opening a file to write on it will clear all data inside it
    logbook.close()
    plants = open('plants', 'w')
    plants.close()
    fert = open('fert', 'w')
    fert.close()

    Fertilizer_ID = 1#sets it back to one
    Plant_ID = 1
    Log_ID = 1
    print()
    print('Data Reset Successful')
    print()



###########################################################################################################################
def ceasarcipher(x):#ill explain this in finer detail
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    newx = ""#i chose to append the letters instead since in my intuition, replacing the letters instead would be trickier
    for i in x:#for each letter in the word im willing to encrypt
        atrue = False
        if i in alphabet:#if the letter is in the alphabet, that letter will be encrypted. Else, it will simply be appended unencrypted
            for a in range(len(alphabet)):#checking which letter is it in the alphabet string
                if i == alphabet[a]:#special case: if
                    if alphabet[a] == 'a':#special case: if i = 'a', then the same thing will happen to it as the other letters, however, for loop checks rightwards, and 'a' turns to '9' which would be checked again
                        i = alphabet[a-1]#letters shift to the left
                        newx = newx + i
                        atrue = True#this is why this variable is here to not make it repeat the checking if it is an encrypted 'a'
                    elif alphabet[a] == '9':#this is the application of atrue
                        if atrue == True:#if the '9' is an encrypted 'a', it will not be encrypted further
                            i = i
                        else:#if it is a normal '9', it will be encrypted instead
                            i = alphabet[a - 1]
                    else:#if it is an another letter, it would be encrypted normally
                        i = alphabet[a-1]
                    if atrue == False:#encrypting letters for all letters except a
                        newx = newx + i
        else:
            newx = newx + i

    return newx


def ceasardecipher(x):#same format but reversed
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    newx = ""
    for i in x:
        atrue = False
        if i in alphabet:
            for a in range(len(alphabet) - 1, -1, -1):
                if i == alphabet[a]:
                    if alphabet[a] == '9':
                        i = alphabet[0]
                        newx = newx + i
                        atrue = True
                    elif alphabet[a] == 'a':
                        if atrue == True:
                            i = i
                        else:
                            i = alphabet[a + 1]
                    else:
                        i = alphabet[a + 1]
                    if atrue == False:
                        newx = newx + i
        else:
            newx = newx + i

    return newx


def savefile():
    global logdic
    global plantsdic
    global fertdic
    
    logbook = open('logbook', 'w')#i use ';' instead because its simple to seperate later with this
    for a, b in logdic.items():
        logbook.write(ceasarcipher(str(a)) + ';' + ceasarcipher(str(b[0])) + ';' + ceasarcipher(str(b[1])) + ';' + ceasarcipher(str(b[2])) + ';' + ceasarcipher(str(b[3])) + '\n')
    logbook.close()
	
    plants = open('plants', 'w')
    for c, d in plantsdic.items():
        plants.write(ceasarcipher(str(c)) + ';' + ceasarcipher(str(d[0])) + ';' + ceasarcipher(str(d[1])))
        for e, f in d[2].items():
            plants.write(";" + ceasarcipher(str(e)) + ";")
            plants.write(ceasarcipher(str(f)))
        plants.write("\n")
    plants.close()

    fert = open('fert', 'w')
    for g, h in fertdic.items():
        fert.write(ceasarcipher(str(g)) + ';' + ceasarcipher(str(h[0])) + ';' + ceasarcipher(str(h[1])) + ';' + ceasarcipher(str(h[2])) + '\n')
    fert.close()

    print('Successfully Saved File')


def loadfile(): #This loads the saved balance and game library
    global logdic
    global plantsdic
    global fertdic
    global Log_ID
    global Plant_ID
    global Fertilizer_ID
    logdic = {}
    logbook = open('logbook', 'r')
    for a in logbook:
        d = a[:-1].split(';')
        print(d)
        print(ceasardecipher(d))
        logdic[ceasardecipher(d[0])] = [ceasardecipher(d[1]), ceasardecipher(d[2]), ceasardecipher(d[3]), ceasardecipher(d[4])]
        Log_ID = int(ceasardecipher(d[0])[1]) + 1#i did this so that repeating ids wouldnt happen. For instance, plant id starts at 1 then at my load file, there is a P1
    logbook.close()

    plantsdic = {}
    plants = open('plants', 'r')
    for b in plants:
        e = b[:-1].split(';')
        f = {}
        for i in range(len(e) - 3):
            if (i+3)%2 == 1:
                x = ceasardecipher(e[i+3])
            else:
                y = float(ceasardecipher(e[i+3]))
                f[x] = y

        plantsdic[ceasardecipher(e[0])] = [ceasardecipher(e[1]), ceasardecipher(e[2]), f]
        Plant_ID = int(ceasardecipher(e[0])[1]) + 1
    plants.close()

    fertdic = {}
    fert = open('fert', 'r')
    for c in fert:
        g = c[:-1].split(';')
        fertdic[ceasardecipher(g[0])] = [ceasardecipher(g[1]), float(ceasardecipher(g[2])), ceasardecipher(g[3])]
        Fertilizer_ID = int(ceasardecipher(g[0])[1]) + 1
    fert.close()
    print("Successfully Loaded File")

while True:#main menu, simple enough
    print('======================================================================================')
    print('     CMSC 12 Project                                                                  ')
    print('                                                                                      ')
    print(' Plants Section:                                                                      ')
    print('  [1] Add Plant              [2] Delete Plant              [3] View Plant             ')
    print('  [4] Edit Plant             [5] Update Nourishment        [6] Nourish Plant          ')
    print('                                                                                      ')
    print(' Fertilizer Section:                                                                  ')
    print('  [7] Purchase Fertilizer    [8] View Fertilizer           [9] View All Fertilizers   ')
    print('  [10] View Affected Plants                                                           ')
    print('                                                                                      ')
    print(' Logbook Section:                                                                     ')
    print('  [11] View All Entries      [12] View Transactions per Action                        ')
    print('                                                                                      ')
    print(' File Section:                                                                        ')
    print('  [13] Save File             [14] Load File                [15] Data Reset            ')
    print('======================================================================================')
    print()
    z = input("\nInput the number to do the function(Input x to exit): ")
    if z == "1":
        addplant()
    elif z == "2":
        deleteplant()
    elif z == "3":
        viewplant()
    elif z == "4":
        editplant()
    elif z == "5":
        updatenourishment()
    elif z == "6":
        nourishplant()
    elif z == "7":
        purchasefertilizer()
    elif z == "8":
        viewfertilizer()
    elif z == "9":
        viewallfertilizers()
    elif z == "10":
        view_affected_plants()
    elif z == "11":
        viewallentries()
    elif z == "12":
        viewtransactionsperaction()
    elif z == "13":
        savefile()
    elif z == "14":
        loadfile()
    elif z == "15":
        datareset()
    elif z == "x":
        print('Thank you for using this program!!!')
        break
    elif z == "X":
        print('Thank you for using this program!!!')
        break
    else:
        print()
        print('Invalid Input!!!')
        print()
