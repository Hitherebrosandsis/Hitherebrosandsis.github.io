package application;

public interface Data {//gives variables to repeated strings to avoid typographical errors
	//courses
	String CMSC = "BS Computer Science";
	String MSCS = "MS Computer Science";
	String MIT = "Master of Information Technology";
	String PHD = "PhD Computer Science";
	//days
	String MONDAY = "Monday";
	String TUESDAY = "Tuesday";
	String WEDNESDAY = "Wednesday";
	String THURSDAY = "Thursday";
	String FRIDAY = "Friday";
	String SATURDAY = "Saturday";
}
