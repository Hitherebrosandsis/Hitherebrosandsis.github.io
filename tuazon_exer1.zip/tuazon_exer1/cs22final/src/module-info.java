open module AbdonAlmoceraLabayTuazonCD5L {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
	
//	opens application to javafx.graphics, javafx.fxml, javafx.base;
}
