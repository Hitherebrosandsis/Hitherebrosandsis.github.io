global _start
global _convert_int_to_str
global _convert_str_to_int

section .data
	SYS_EXIT equ 60

	menu db 10, "***********MENU************", 10, "[1] Convert to Minutes", 10, "[2] Convert to Hours", 10, "[0] Exit", 10, "******************", 10, "Choice: "
	menuLength equ $-menu

	menuchoice db 0

	invalidChoice db 10, "Invalid choice!", 10
	invalidChoiceLength equ $-invalidChoice

	entere db 10, "Enter time in seconds (5-digits): "
	enterLength equ $-entere

	seconds dq 0

section .bss
	strseconds resb 5
	stroutput resb 4

section .text
	_start:
		main_menu:
			mov rax, 1
			mov rdi, 1
			mov rsi, menu
			mov rdx, menuLength
			syscall

			mov rax, 0
			mov rdi, 0
			mov rsi, menuchoice
			mov rdx, 2
			syscall

			mov rdi, menuchoice

			mov al, "1"
			scasb
			je minutes

			mov rdi, menuchoice
			
			mov al, "2"
			scasb
			je hours

			mov rdi, menuchoice

			mov al, "0"
			scasb
			je exit_here

		invalid_choice:
			mov rax, 1
			mov rdi, 1
			mov rsi, invalidChoice
			mov rdx, invalidChoiceLength
			syscall

			jmp main_menu

		minutes:
			mov rax, 1
			mov rdi, 1
			mov rsi, entere
			mov rdx, enterLength
			syscall
			
			mov rax, 0
			mov rdi, 0
			mov rsi, strseconds
			mov rdx, 6
			syscall

			call _convert_str_to_int

			mov rax, qword[seconds]

			mov rbx, 60

			div rbx

			mov qword[seconds], rax

			mov rdx, 0

			call _convert_int_to_str

			mov rax, 1
			mov rdi, 1
			mov rsi, stroutput
			mov rdx, 5
			syscall

			jmp main_menu


		hours:
			mov rax, 1
			mov rdi, 1
			mov rsi, entere
			mov rdx, enterLength
			syscall
			
			mov rax, 0
			mov rdi, 0
			mov rsi, strseconds
			mov rdx, 6
			syscall

			call _convert_str_to_int

			mov rax, qword[seconds]

			mov rbx, 3600

			div rbx

			mov qword[seconds], rax

			mov rdx, 0

			call _convert_int_to_str

			mov rax, 1
			mov rdi, 1
			mov rsi, stroutput
			mov rdx, 5
			syscall

			jmp main_menu
		
		exit_here:
			mov rax, SYS_EXIT
			xor rdi, rdi
			syscall













	_convert_str_to_int:
		mov rdi, 0
		mov rsi, strseconds
		mov rcx, 0
		mov rbx, 5
		mov r8, 10
		cld

		loop0:
			mov rax, 0
			
			lodsb
			sub rax, 48

			mov rcx, rbx
			dec rcx
			
			exponent:
				loop1:
					cmp rcx, 0
					jle endloop
					mul r8
					dec rcx
					jmp loop1
					
				endloop:

			add rdi, rax

			dec rbx
			cmp rbx, 0
			jg loop0
		
		mov rax, rdi
        mov qword[seconds], rax

		mov rdi, 0
		mov rsi, 0
		mov rcx, 0
		mov rbx, 0
		mov r8, 0
		mov rax, 0

		ret

	_convert_int_to_str:
		mov rcx, 4
		lea rdi, [stroutput+rcx-1]
		mov rax, qword[seconds]
		mov r8, 10
		
		std

		loop2:
			div r8
			mov rbx, rax
			mov rax, rdx
			add rax, 48
			stosb
			mov rax, rbx
			mov rdx, 0
			loop loop2	

		mov rdi, 0
		mov rsi, 0
		mov rcx, 0
		mov rbx, 0
		mov r8, 0
		mov rax, 0

		ret





