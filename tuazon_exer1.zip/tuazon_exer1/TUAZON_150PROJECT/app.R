options("width" = 200)

library(shiny)
library(bslib)

source("tableau_builder.R")

# Define UI ----
ui <- page_navbar(
    title = "CMSC 150 Project",
    bg = "#7b1113",
    # Panel with table ----
    nav_panel("Calculator", 
              layout_columns(
                card(
                  card_header("Input"),
                  checkboxGroupInput(
                    "projects",
                    "Select all that apply",
                    choices = list("Large Solar Park" = 1,
                                   "Small Solar Installations" = 2,
                                   "Wind Farm"= 3,
                                   "Gas-to-renewables conversion" = 4,
                                   "Boiler Retrofit" = 5,
                                   "Catalytic Converters for Buses" = 6,
                                   "Diesel Bus Replacement" = 7,
                                   "Traffic Signal/Flow Upgrade" = 8,
                                   "Low-Emission Stove Program" = 9,
                                   "Residential Insulation/Efficiency" = 10,
                                   "Industrial Scrubbers" = 11,
                                   "Waste Methane Capture System" = 12,
                                   "Landfill Gas-to-energy" = 13,
                                   "Reforestation (acre-package)" = 14,
                                   "Urban Tree Canopy Program (street trees)" = 15,
                                   "Industrial Energy Efficiency Retrofit" = 16,
                                   "Natural Gas Leak Repair" = 17,
                                   "Agricultural Methane Reduction" = 18,
                                   "Clean Cookstove & Fuel Switching (community scale)" = 19,
                                   "Rail Electrification" = 20,
                                   "EV Charging Infrastructure" = 21,
                                   "Biochar for soils (per project unit)" = 22,
                                   "Industrial VOC" = 23,
                                   "Heavy-Duty Truck Retrofit" = 24,
                                   "Port/Harbor Electrification" = 25,
                                   "Black Carbon reduction" = 26,
                                   "Wetlands restoration" = 27,
                                   "Household LPG conversion program" = 28,
                                   "Industrial process change" = 29,
                                   "Behavioral demand-reduction program" = 30
                                   ),
                    selected = 1
                  ),
                  actionButton("submit", "Submit")
                ),
                
                card(
                  card_header("Output"),
                  uiOutput("Input"),
                  uiOutput("Output"),
                  verbatimTextOutput("Table")
                ),
                col_widths = c(3, 9)
                
            ),
            card(
              height = 1000,
              card_header("Iterations"),
              verbatimTextOutput("Iterations")
              )
            
    
    ),
    
    # Panel with summary ----
    nav_panel("Complete Pollutant Reductions per Project Unit", 
              imageOutput("reductionimage"))
)

# Define server logic ----
server <- function(input, output) {
  project = list("Large Solar Park",
       "Small Solar Installations",
       "Wind Farm",
       "Gas-to-renewables conversion",
       "Boiler Retrofit",
       "Catalytic Converters for Buses",
       "Diesel Bus Replacement",
       "Traffic Signal/Flow Upgrade",
       "Low-Emission Stove Program",
       "Residential Insulation/Efficiency",
       "Industrial Scrubbers",
       "Waste Methane Capture System",
       "Landfill Gas-to-energy",
       "Reforestation (acre-package)",
       "Urban Tree Canopy Program (street trees)",
       "Industrial Energy Efficiency Retrofit",
       "Natural Gas Leak Repair",
       "Agricultural Methane Reduction",
       "Clean Cookstove & Fuel Switching (community scale)",
       "Rail Electrification",
       "EV Charging Infrastructure",
       "Biochar for soils (per project unit)",
       "Industrial VOC",
       "Heavy-Duty Truck Retrofit",
       "Port/Harbor Electrification",
       "Black Carbon reduction",
       "Wetlands restoration",
       "Household LPG conversion program",
       "Industrial process change",
       "Behavioral demand-reduction program"
  )
  
  output$reductionimage <- renderImage({ 
    filename <- normalizePath(file.path('./images','reduction.jpg'))
    
    list(src = filename,
         width = "100%",
         alt = "reduction image")
  }, deleteFile = FALSE)
  
  #apply x <- reactive({function(input$*)})
  
  x <- eventReactive(input$submit, {
    input$projects
  })
  
  a <- reactive({
    a <- func(x())
  })
  
  #Input portion 
  output$Input <- renderUI({
      HTML(paste("Your Input<br>", paste("- ",
                                         project[as.integer(x())],
                                         collapse = "<br>"),
                 "<br><br>"
            )
           )
      })
  
  #Output portion
  output$Output <- renderUI({
    if(a()$feasibility){
      HTML(paste("The Optimized Cost<br>", as.character(a()$Z), "<br><br>"
                )
        )
    }
    else{
      HTML(paste("The problem is infeasible", "<br><br>"))
    }
  })
  
  output$Table <- renderPrint({
    if(a()$feasibility){table(a()$basicSolution)}
    else{}
  })
  
  #Iteration portion
  printIter <- function() {
    print("The iteration stops at:")
    print(a()$iter)
    print("")
    for(i in 1:(a()$iter)){
      print("Iteration:")
      print(i)
      print((a()$itertab)[[i]])
      print((a()$iterbas)[[i]])
    }
  }
  
  output$Iterations <- renderPrint({
    printIter()
  })
  
}

# Run the app ----
shinyApp(ui = ui, server = server)