options(max.print = 10000)

mintableau <- function(tableau){
  mintableau = c()
  #x values
  for(i in 1:(ncol(tableau) - nrow(tableau))){
    #xvalues
    for(j in 1:(nrow(tableau) - 1)){
      if(i == (ncol(tableau) - nrow(tableau))){
        mintableau <- append(mintableau, -(tableau[j, ncol(tableau)]))
      }
      
      else{
        mintableau <- append(mintableau, tableau[j, i])
      }
    }
    
    #svalues
    for(j in 1:(ncol(tableau) - nrow(tableau))){
      if(i != j){
        mintableau <- append(mintableau, 0)
      }
      
      else{
        mintableau <- append(mintableau, 1)
      }
    }
    
    #rhs
    if(i == (ncol(tableau) - nrow(tableau))){
      mintableau <- append(mintableau, 0)
    }
    else{
      mintableau <- append(mintableau, -(tableau[nrow(tableau), i]))
    }
    
  }
  
  min <- matrix(mintableau, nrow = (ncol(tableau) - nrow(tableau)), ncol = ncol(tableau), byrow = T)
  return(min)
}
##################################################################################
BasicSolution <- function(tableau, isMax){
  columns <- c()
  
  if(isMax){
    #To separate the orig variables to the slack variables
    n = ncol(tableau) - nrow(tableau) - 1
    
    #bottom functions for basic solutions column names
    
    for(i in 1:n){
      columns <- append(columns, paste("x", i))
    }
    
    a = 1
    
    for(i in (n+1):(ncol(tableau)-2)){
      columns <- append(columns, paste("S", a))
      a <- a + 1
    }
    
    columns <- append(columns, "Z")
    
    
  }
  
  else{
    #To separate the orig variables to the slack variables
    n = ncol(tableau) - nrow(tableau) - 1
    
    for(i in 1:n){
      columns <- append(columns, paste("S", i))
    }
    
    
    for(i in (n+1):(ncol(tableau) - 2)){
      columns <- append(columns, paste("x", (i-n)))
    }
    
    columns <- append(columns, "Z")
  }
  
  #basic solution function
  basicsolution = c()
  if(isMax){
    for(j in 1:(ncol(tableau) - 1)){
      onenonzero = FALSE
      nonzero = NA
      
      for(i in 1:nrow(tableau)){
        #is it a nonzero number
        if(tableau[i,j] != 0){
          #is there already a nonzero number
          if(onenonzero == FALSE){
            nonzero = tableau[i,ncol(tableau)]/tableau[i,j]
            onenonzero = TRUE
          }
          else{
            onenonzero = FALSE
            break
          }
          
        }
      }
      #0 if theres multiple or no nonzero
      if(onenonzero){
        basicsolution <- append(basicsolution, nonzero)
      }
      else{
        basicsolution <- append(basicsolution, 0)
      }
    }
  }
  
  else{
    for(i in 1:(ncol(tableau) - 1)){
      if(i == (ncol(tableau) - 1)){
        basicsolution <- c(basicsolution, tableau[nrow(tableau), ncol(tableau)])
      }
      
      else{
        basicsolution <- c(basicsolution, tableau[nrow(tableau), i])
      }
    }
  }
  
  basicSolution <- matrix(basicsolution, nrow = 1, 
                         ncol = length(basicsolution), byrow = TRUE,
                         dimnames = list(c("values"), columns))
  
  return(basicSolution)
}
######################################################################################
Simplex <- function(tableau, isMax) {
  
  #The function for Simplex Method
  isnegative = TRUE
  itertab_ = list()
  iterbas_ = list()
  feasibility = T
  iter = 1
  #happens while everything at the last row is negative
  while(isnegative){
    itertab_[[iter]] <- tableau############# only change to get each iteration
    iterbas_[[iter]] <- BasicSolution(tableau, isMax)
    iter <- iter + 1
    isnegative = FALSE
    #find the least number in the bottom row
    LC = NULL
    
    for(i in 1:(ncol(tableau) - 1)){
      if(is.null(LC)){
        #get its column
        LC = tableau[,i]
      }
      if(tableau[nrow(tableau), i] < LC[length(LC)]){
        #get its column
        LC = tableau[,i]
      }
    }
    
    #get the PE thru getting the least ratio beside bottom row
    PR = NA
    PE = NA
    LR = NA
    for(i in 1:(length(LC) - 1)){
      if(LC[i] > 0){
        if(is.na(PE) || (tableau[i,ncol(tableau)]/LC[i] < LR)){
          #get the PE which is the number in the column
          PE <- LC[i]
          LR <- (tableau[i,ncol(tableau)]/LC[i])
          #get its row
          PR <- i
        }
      }
    }
    
    #normalize
    NR <- tableau[PR,]/PE
    
    #deduct on all
    if(is.na(PR)){
      feasibility = F
      break
    }
    for(i in 1:length(LC)){
      if(i != PR){
        tableau[i,] <- tableau[i,] - (NR * LC[i])
      }
      else{
        tableau[i,] <- NR
      }
    }
    #check
    for(i in 1:(length(tableau[nrow(tableau),]) - 1)){
      if(tableau[nrow(tableau), i] < 0){
        isnegative = TRUE
        break
      }
    }
    
  }
  
  return(list(finalTableau = tableau, 
              basicSolution = BasicSolution(tableau, isMax), 
              Z = tableau[nrow(tableau), ncol(tableau)],
              itertab = itertab_,
              iterbas = iterbas_,
              feasibility = feasibility,
              iter = iter - 1)
  )
}
######################################################################################
func <- function(chosen){
  pollutantred = list(c(60, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                      c(18, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                      c(55, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                      c(25, 1, 0.2, 0.1, 1.5, 0.5, 2, 0.05, 0.01, 0.3),
                      c(20, 0.9, 0.4, 0.2, 0.1, 0.05, 1.2, 0.02, 0.01, 0.05),
                      c(30, 2.8, 0.6, 0.8, 0, 0.5, 5, 0.01, 0.05, 0.02),
                      c(48, 3.2, 0.9, 1, 0, 0.7, 6, 0.02, 0.08, 0.03),
                      c(12, 0.6, 0.1, 0.4, 0.05, 0.2, 3, 0.02, 0.02, 0.01),
                      c(2, 0.02, 0.01, 0.7, 0, 0.01, 1.5, 0.03, 0.2, 0),
                      c(15, 0.1, 0.05, 0.05, 0.02, 0.02, 0.5, 0, 0, 0.01),
                      c(6, 0.4, 6, 0.4, 0, 0.1, 0.6, 0.01, 0.01, 0),
                      c(28, 0.2, 0.1, 0.05, 8, 0.2, 0.1, 0, 0, 0.05),
                      c(24, 0.15, 0.05, 0.03, 6.5, 0.1, 0.05, 0, 0, 0.03),
                      c(3.5, 0.04, 0.02, 0.01, 0.8, 0.03, 0.1, 0.01, 0.005, 0.005),
                      c(4.2, 0.06, 0.01, 0.03, 0.6, 0.02, 0.15, 0.005, 0.02, 0.002),
                      c(22, 0.5, 0.3, 0.15, 0.2, 0.1, 1, 0.01, 0.01, 0.03),
                      c(10, 0.05, 0.01, 0.01, 4, 0.02, 0.02, 0, 0, 0.01),
                      c(8, 0.02, 0.01, 0.02, 7.2, 0.05, 0.02, 0.1, 0, 0.05),
                      c(3.2, 0.04, 0.02, 0.9, 0.1, 0.02, 2, 0.05, 0.25, 0),
                      c(80, 2, 0.4, 1.2, 0, 0.6, 10, 0.02, 0.1, 0.05),
                      c(20, 0.3, 0.05, 0.1, 0, 0.05, 0.5, 0.01, 0.01, 0.01),
                      c(6, 0.01, 0, 0.01, 2.5, 0.01, 0.01, 0.2, 0, 0.02),
                      c(2, 0.01, 0, 0, 0, 6.5, 0.1, 0, 0, 0),
                      c(36, 2.2, 0.6, 0.6, 0, 0.3, 4.2, 0.01, 0.04, 0.02),
                      c(28, 1.9, 0.8, 0.7, 0, 0.2, 3.6, 0.01, 0.03, 0.02),
                      c(1.8, 0.02, 0.01, 0.6, 0.05, 0.01, 1, 0.02, 0.9, 0),
                      c(10, 0.03, 0.02, 0.02, 3.2, 0.01, 0.05, 0.15, 0.02, 0.04),
                      c(2.5, 0.03, 0.01, 0.4, 0.05, 0.02, 1.2, 0.03, 0.1, 0),
                      c(3, 0.02, 0.01, 0, 0, 0, 0, 0, 0, 1.5),
                      c(9, 0.4, 0.05, 0.05, 0.01, 0.3, 2.5, 0.01, 0.01, 0.01)
  )
  
  #initialize project list
  projects <- list(
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
    c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
  )
  
  for(j in chosen){
    projects[as.integer(j)] <- pollutantred[as.integer(j)]
  }

  pollutants = c(1000
                 ,35
                 ,25
                 ,20
                 ,60
                 ,45
                 ,80
                 ,12
                 ,6
                 ,10
                 )
  
  minprojects = c()
  
  cost = c(4000,
           1200,
           3800,
           3200,
           1400,
           2600,
           5000,
           1000,
           180,
           900,
           4200,
           3600,
           3400,
           220,
           300,
           1600,
           1800,
           2800,
           450,
           6000,
           2200,
           1400,
           2600,
           4200,
           4800,
           600,
           1800,
           700,
           5000,
           400
           )
  
#########################################################################################

  tableau = matrix(, 
                   nrow = (length(pollutants) + length(projects) + 1),
                   #minpollutant equations, inequalities, formula
                   ncol = (length(projects) + (length(pollutants) + length(projects) + 1) + 1), 
                   #variables = length(projects); slackvariables = amount of equations; 
                   byrow = TRUE)
  
####################################################################################
  
  #finding the mincost
  
  #minpollutant formula
  for(i in 1:length(pollutants)){
    for(j in 1:length(projects)){
      tableau[i, j] <- projects[[j]][i]
    }
    
    #last column
    tableau[i, ncol(tableau)] <- pollutants[i]
  }
  
  #constraints
  # x <= 20 -> -20 = -x + S
  for(i in 1:length(projects)){
    for(j in 1:length(projects)){
      if(i == j){
        tableau[(i + length(pollutants)), j] <- -1
      }
      else{
        tableau[(i + length(pollutants)), j] <- 0
      }
    }
    
    #last column
    tableau[(i + length(pollutants)), ncol(tableau)] <- -20
  }
  
  #last row
  for(j in 1:length(projects)){
    tableau[nrow(tableau), j] <- -cost[j]
  }
  #last row, last column
  tableau[nrow(tableau), ncol(tableau)] <- 0
  
  #slack variable + Z square
  for(i in 1:nrow(tableau)){
    for(j in 1:nrow(tableau)){
      if(i == j){
        tableau[i, (j + length(projects))] <- 1
      }
      else{
        tableau[i, (j + length(projects))] <- 0
      }
    }
  }
  output <- mintableau(tableau)
  
  #append
  return(Simplex(output, F))
}
#####################################################################################

table <- function(basicsol){
  
  projects = c("Large Solar Park",
               "Small Solar Installations",
               "Wind Farm",
               "Gas-to-renewables conversion",
               "Boiler Retrofit",
               "Catalytic Converters for Buses",
               "Diesel Bus Replacement",
               "Traffic Signal/Flow Upgrade",
               "Low-Emission Stove Program",
               "Residential Insulation/Efficiency",
               "Industrial Scrubbers",
               "Waste Methane Capture System",
               "Landfill Gas-to-energy",
               "Reforestation (acre-package)",
               "Urban Tree Canopy Program (street trees)",
               "Industrial Energy Efficiency Retrofit",
               "Natural Gas Leak Repair",
               "Agricultural Methane Reduction",
               "Clean Cookstove & Fuel Switching (community scale)",
               "Rail Electrification",
               "EV Charging Infrastructure",
               "Biochar for soils (per project unit)",
               "Industrial VOC",
               "Heavy-Duty Truck Retrofit",
               "Port/Harbor Electrification",
               "Black Carbon reduction",
               "Wetlands restoration",
               "Household LPG conversion program",
               "Industrial process change",
               "Behavioral demand-reduction program")
  
  cost = c(4000,
           1200,
           3800,
           3200,
           1400,
           2600,
           5000,
           1000,
           180,
           900,
           4200,
           3600,
           3400,
           220,
           300,
           1600,
           1800,
           2800,
           450,
           6000,
           2200,
           1400,
           2600,
           4200,
           4800,
           600,
           1800,
           700,
           5000,
           400
  )
  
  table <- matrix(, nrow = 30, ncol = 3, 
                 dimnames = list(NULL, c("Mitigation Project", "Number of Project Units", "Cost($)")))
  
  for(i in 1:30){
    table[i,1] <- projects[i]
    table[i,2] <- basicsol[1, 40 + i]
    table[i,3] <- basicsol[1, 40 + i] * cost[i]
  }
  
  return(table)
}
#print(Simplex(mintableau(matrix(c(1, 2, 1, 0, 0, 0, 0, 4,
#                          7, 6, 0, 1, 0, 0, 0, 20,
#                          1, 0, 0, 0, 1, 0, 0, 0,
#                          0, 1, 0, 0, 0, 1, 0, 0,
#                          -14, -20, 0, 0, 0, 0, 1, 0), nrow = 5, ncol = 8, byrow = T)), F)$Z)
#

#print(table((func(list(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
#               21, 22, 23, 24, 25, 26, 27, 28, 29, 30))$basicSolution)))

