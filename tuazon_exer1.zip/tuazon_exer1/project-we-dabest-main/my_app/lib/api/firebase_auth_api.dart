import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseAuthAPI {
  final FirebaseAuth auth = FirebaseAuth.instance;

  Stream<User?> get getUser => auth.authStateChanges();

  Future<UserCredential> signIn(String email, String password) async {
      return await auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<UserCredential> signUp(String email, String password, String name) async {
    try {
      // Create a new user account in Firebase authentication using email and password
      final userCredential = await auth.createUserWithEmailAndPassword(email: email, password: password);

      // After user creation, store data in Firestore
      await FirebaseFirestore.instance
        .collection("users")
        .doc(userCredential.user!.uid)
        .set({
          "name": name, "email": email, "profileCompleted": false,
        });

      return userCredential;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        throw Exception('The account already exists for that email.');
      } else if (e.code == 'weak-password') {
        throw Exception('The password provided is too weak.');
      } else {
        throw Exception('Failed to sign up: ${e.message}');
      }
    }
  }

  Future<void> signOut() async {
    await auth.signOut();
  }
}
