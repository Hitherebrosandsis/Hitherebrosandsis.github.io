import 'package:cloud_firestore/cloud_firestore.dart';

class ItemModel {
  final String id;
  final String title;
  final String description;
  final String ownerId;
  final String ownerName;
  final String imageUrl;

  final String status; // available, requested, reserved, completed
  final String? requestedBy; // userId of requester

  final DateTime createdAt;
  final DateTime expirationDate;

  final List<String> tags;

  final double? latitude;
  final double? longitude;
  final String? locationName; // address

  final DateTime pickupTime;

  final String? qrCodeString;

  ItemModel({
    required this.id,
    required this.title,
    required this.description,
    required this.ownerId,
    required this.ownerName,
    required this.imageUrl,
    required this.status,
    required this.createdAt,
    required this.expirationDate,
    this.requestedBy,
    required this.tags,
    this.latitude,
    this.longitude,
    this.locationName,
    required this.pickupTime,
    this.qrCodeString
  });

  factory ItemModel.fromFirestore(Map<String, dynamic> data, String id) {
    return ItemModel(
      id: id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      ownerId: data['ownerId'] ?? '',
      ownerName: data['ownerName'] ?? '',
      imageUrl: data['imageUrl'] ?? '',
      status: data['status'] ?? 'available',
      requestedBy: data['requestedBy'],
      createdAt: (data['createdAt'] != null)
          ? (data['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
      expirationDate: (data['expirationDate'] != null)
          ? (data['expirationDate'] as Timestamp).toDate()
          : DateTime.now().add(const Duration(days: 1)),
      tags: List<String>.from(data['tags'] ?? []),
      latitude: (data['latitude'] as num?)?.toDouble(),
      longitude: (data['longitude'] as num?)?.toDouble(),
      locationName: data['locationName'],
      pickupTime: data['pickupTime'] != null
          ? (data['pickupTime'] as Timestamp).toDate()
          : DateTime.now(),
      qrCodeString: data['qrCodeString']
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'ownerId': ownerId,
      'ownerName': ownerName,
      'imageUrl': imageUrl,
      'status': status,
      'requestedBy': requestedBy,
      'createdAt': Timestamp.now(),
      'expirationDate': Timestamp.fromDate(expirationDate),
      'tags': tags,
      'latitude': latitude,
      'longitude': longitude,
      'locationName': locationName,
      'pickupTime': Timestamp.fromDate(pickupTime),
      'qrCodeString': qrCodeString
    };
  }
}
