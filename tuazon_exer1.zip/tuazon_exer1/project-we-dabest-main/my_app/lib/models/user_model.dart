class UserModel {
  final String uid;
  final String fullName;
  final String email;
  final List<String> tags;

  final String verificationSelfieUrl;

  final bool profileCompleted;

  final bool itemAlerts;
  final bool pickupReminders;

  UserModel({
    required this.uid,
    required this.fullName,
    required this.email,
    required this.tags,
    required this.verificationSelfieUrl,
    required this.profileCompleted,
    required this.itemAlerts,
    required this.pickupReminders,
  });

  factory UserModel.fromFirestore(
    Map<String, dynamic> data,
    String uid,
  ) {
    return UserModel(
      uid: uid,
      fullName: data['fullName'] ?? '',
      email: data['email'] ?? '',
      tags: List<String>.from(data['tags'] ?? []),
      verificationSelfieUrl: data['verificationSelfieUrl'] ?? '',
      profileCompleted: data['profileCompleted'] ?? false,
      itemAlerts: data['itemAlerts'] ?? true,
      pickupReminders: data['pickupReminders'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'fullName': fullName,
      'email': email,
      'tags': tags,
      'verificationSelfieUrl': verificationSelfieUrl,
      'profileCompleted': profileCompleted,
      'itemAlerts': itemAlerts,
      'pickupReminders': pickupReminders,
    };
  }
}
