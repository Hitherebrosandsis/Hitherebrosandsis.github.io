import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/app_theme.dart';
import '../../services/notification_service.dart';
import '../../models/item_model.dart';
import '../item/item_detail_screen.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: AppColors.base,
      appBar: AppBar(
        title: const Text("Notifications"),
        backgroundColor: AppColors.accent,
        actions: [
          IconButton(
            icon: const Icon(Icons.done_all),
            onPressed: () async {
              final user = FirebaseAuth.instance.currentUser;

              final unread = await FirebaseFirestore.instance
                  .collection('notifications')
                  .where(
                    'userId',
                    isEqualTo: user!.uid,
                  )
                  .where(
                    'isRead',
                    isEqualTo: false,
                  )
                  .get();

              for (var doc in unread.docs) {
                await FirebaseFirestore.instance
                    .collection('notifications')
                    .doc(doc.id)
                    .update({
                  'isRead': true,
                });
              }
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('notifications')
            .where(
              'userId',
              isEqualTo: user!.uid,
            )
            .orderBy(
              'createdAt',
              descending: true,
            )
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          final notifications = snapshot.data!.docs;

          if (notifications.isEmpty) {
            return const Center(
              child: Text("No notifications"),
            );
          }

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final notif = notifications[index];

              final data = notif.data() as Map<String, dynamic>;

              return ListTile(
                tileColor: data['isRead'] == true
                    ? Colors.white
                    : Colors.blue.withOpacity(0.08),
                leading: Icon(data['type'] == 'request'
                    ? Icons.shopping_bag
                    : data['type'] == 'accepted'
                        ? Icons.check_circle
                        : data['type'] == 'rejected'
                            ? Icons.cancel
                            : data['type'] == 'completed'
                                ? Icons.done_all
                                : data['type'] == 'pickup_reminder'
                                    ? Icons.schedule
                                    : data['type'] == 'dietary_match'
                                        ? Icons.restaurant
                                        : Icons.notifications),
                title: Text(
                  data['title'] ?? '',
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data['body'] ?? ''),
                    const SizedBox(height: 4),
                    Text(
                      data['createdAt'] != null
                          ? "${(data['createdAt'] as Timestamp).toDate().month}/"
                              "${(data['createdAt'] as Timestamp).toDate().day}/"
                              "${(data['createdAt'] as Timestamp).toDate().year}"
                          : "",
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
                trailing: data['isRead'] == true
                    ? null
                    : const Icon(
                        Icons.circle,
                        size: 10,
                        color: Colors.blue,
                      ),
                onTap: () async {
                  await NotificationService.markAsRead(
                    notif.id,
                  );

                  final itemId = data['itemId'];

                  if (itemId == null) return;

                  final doc = await FirebaseFirestore.instance
                      .collection('items')
                      .doc(itemId)
                      .get();

                  if (!doc.exists) return;

                  final item = ItemModel.fromFirestore(
                    doc.data()!,
                    doc.id,
                  );

                  if (!context.mounted) return;

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ItemDetailScreen(
                        item: item,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
