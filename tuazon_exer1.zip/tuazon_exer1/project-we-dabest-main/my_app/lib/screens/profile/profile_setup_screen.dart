import 'package:flutter/material.dart';
import 'package:my_app/providers/auth_provider.dart' as app_auth;
import 'package:provider/provider.dart';
import '../../core/app_theme.dart';
import '../../widgets/tag_chip.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import '../auth/auth_wrapper.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final TextEditingController nameController = TextEditingController();

  File? selfieImage;
  String? selfieBase64;
  final ImagePicker picker = ImagePicker();

  double? latitude;
  double? longitude;
  String locationName = "";
  double selectedRadius = 5;

  final Map<String, List<String>> tagCategories = {
    "Dietary": ["Vegan", "Vegetarian", "Halal", "Keto", "Gluten-Free"],
    "Food Type": [
      "Home-Cooked",
      "Raw Ingredients",
      "Cooked Meals",
      "Snacks",
      "Beverages"
    ],
    "Allergens": ["Dairy-Free", "Nut-Free", "Seafood-Free"],
  };

  List<String> selectedTags = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) return;

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();

    if (doc.exists) {
      setState(() {
        nameController.text = doc.data()?['fullName'] ?? "";
        selectedTags = List<String>.from(
          doc.data()?['tags'] ?? [],
        );
        final loadedSelfie = doc.data()?['verificationSelfieUrl'];
        selfieBase64 = loadedSelfie is String ? loadedSelfie.trim() : '';
        latitude = doc.data()?['latitude']?.toDouble();
        longitude = doc.data()?['longitude']?.toDouble();
        locationName = doc.data()?['locationName'] ?? '';
        selectedRadius = (doc.data()?['discoveryRadius'] ?? 5).toDouble();
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> takeSelfie() async {
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 20,
      maxWidth: 600,
      maxHeight: 600,
    );

    if (picked != null) {
      final bytes = await File(picked.path).readAsBytes();

      setState(() {
        selfieImage = File(picked.path);
        selfieBase64 = base64Encode(bytes);
      });
    }
  }

  Future<void> getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) return;

    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return;
    }

    final position = await Geolocator.getCurrentPosition();

    final placemarks = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );

    final place = placemarks.first;

    setState(() {
      latitude = position.latitude;
      longitude = position.longitude;

      locationName = "${place.locality}, "
          "${place.administrativeArea}";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile Setup"),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Center(
                  child: Image.asset(
                    "assets/images/blue_logo.png",
                    height: 80,
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Your Name",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    hintText: "Enter your name",
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Dietary Preferences",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: tagCategories.entries.map((entry) {
                    final category = entry.key;
                    final tags = entry.value;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 12),
                        Text(
                          category,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: tags.map((tag) {
                            return TagChip(
                              label: tag,
                              selected: selectedTags.contains(tag),
                              onSelected: (val) {
                                setState(() {
                                  if (val) {
                                    selectedTags.add(tag);
                                  } else {
                                    selectedTags.remove(tag);
                                  }
                                });
                              },
                            );
                          }).toList(),
                        ),
                      ],
                    );
                  }).toList(),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Verification Selfie",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Container(
                  height: 180,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.secondary),
                  ),
                  child: Builder(
                    builder: (context) {
                      try {
                        if (selfieBase64 == null ||
                            selfieBase64!.trim().isEmpty) {
                          return const Center(
                            child: Text("No image selected"),
                          );
                        }

                        return ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.memory(
                            base64Decode(selfieBase64!),
                            fit: BoxFit.cover,
                            width: double.infinity,
                          ),
                        );
                      } catch (e) {
                        return const Center(
                          child: Text("Invalid image"),
                        );
                      }
                    },
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: takeSelfie,
                  child: const Text("Take Selfie"),
                ),
                const SizedBox(height: 24),
                const Text(
                  "Location",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: AppColors.accent.withOpacity(0.25),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color:
                            latitude != null ? AppColors.accent : Colors.grey,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              latitude == null
                                  ? "Location not set"
                                  : "Current Location",
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              locationName.isEmpty
                                  ? "Use your current location"
                                  : locationName,
                              style: TextStyle(
                                color: AppColors.dark.withOpacity(0.7),
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: getCurrentLocation,
                  icon: const Icon(Icons.my_location),
                  label: Text(
                    latitude == null ? "Set Location" : "Update Location",
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  "Discovery Radius",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.secondary,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "Nearby Discovery Radius",
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            "${selectedRadius.toInt()} km",
                            style: const TextStyle(
                              color: AppColors.accent,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Slider(
                        value: selectedRadius,
                        min: 1,
                        max: 50,
                        divisions: 49,
                        activeColor: AppColors.accent,
                        inactiveColor: AppColors.secondary,
                        label: "${selectedRadius.toInt()} km",
                        onChanged: (value) {
                          setState(() {
                            selectedRadius = value;
                          });
                        },
                      ),
                      Text(
                        "Only show food within your selected distance.",
                        style: TextStyle(
                          color: AppColors.dark.withOpacity(0.6),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.dark,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  onPressed: () async {
                    final user = FirebaseAuth.instance.currentUser;

                    if (user == null) return;

                    if (nameController.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Name is required")),
                      );
                      return;
                    }
                    if (selectedTags.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "Please select at least one dietary preference.",
                          ),
                        ),
                      );
                      return;
                    }

                    if (selfieBase64 == null || selfieBase64!.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "Verification selfie is required.",
                          ),
                        ),
                      );

                      return;
                    }

                    if (latitude == null || longitude == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            "Location is required.",
                          ),
                        ),
                      );

                      return;
                    }

                    try {
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(user.uid)
                          .set({
                        'fullName': nameController.text.trim(),
                        'tags': selectedTags,
                        'verificationSelfieUrl': selfieBase64 ?? '',
                        'profileCompleted':
                            nameController.text.trim().isNotEmpty &&
                                selectedTags.isNotEmpty &&
                                selfieBase64 != null &&
                                selfieBase64!.trim().isNotEmpty &&
                                latitude != null &&
                                longitude != null,
                        'latitude': latitude,
                        'longitude': longitude,
                        'locationName': locationName,
                        'discoveryRadius': selectedRadius,
                      }, SetOptions(merge: true));
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Failed to save profile: $e")),
                      );
                      return;
                    }

                    final authProvider = Provider.of<app_auth.AuthProvider>(
                        context,
                        listen: false);

                    await authProvider.setProfileCompleted(true);
                    if (!context.mounted) return;
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AuthWrapper(),
                      ),
                      (route) => false,
                    );
                  },
                  child: const Text("Save Profile"),
                ),
              ],
            ),
    );
  }
}
