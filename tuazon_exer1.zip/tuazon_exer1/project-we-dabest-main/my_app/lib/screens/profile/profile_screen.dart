import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/app_theme.dart';
import 'profile_setup_screen.dart';
import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String fullName = "";
  List<String> tags = [];
  String verificationSelfieUrl = "";
  bool isLoading = true;
  bool itemAlerts = true;
  bool pickupReminders = true;

  String locationName = "";
  double discoveryRadius = 5;
  double? latitude;
  double? longitude;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) return;

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();

    if (doc.exists) {
      setState(() {
        fullName = doc['fullName'] ?? "";
        tags = List<String>.from(doc['tags'] ?? []);
        verificationSelfieUrl = doc['verificationSelfieUrl'] ?? "";
        isLoading = false;
        itemAlerts = doc.data()?['itemAlerts'] ?? true;
        pickupReminders = doc.data()?['pickupReminders'] ?? true;
        locationName = doc.data()?['locationName'] ?? "";
        discoveryRadius = (doc.data()?['discoveryRadius'] ?? 5).toDouble();
        latitude = (doc.data()?['latitude'] ?? 0).toDouble();
        longitude = (doc.data()?['longitude'] ?? 0).toDouble();
      });
    }
  }

  Future<void> getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) return;

    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return;
    }

    final position = await Geolocator.getCurrentPosition();

    final placemarks = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );

    final place = placemarks.first;

    final newLocationName = "${place.locality}, "
        "${place.administrativeArea}";

    setState(() {
      latitude = position.latitude;
      longitude = position.longitude;
      locationName = newLocationName;
    });

    final user = FirebaseAuth.instance.currentUser;

    await FirebaseFirestore.instance.collection('users').doc(user!.uid).update({
      'latitude': latitude,
      'longitude': longitude,
      'locationName': newLocationName,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      appBar: AppBar(
        title: const Text("Your Profile"),
        backgroundColor: AppColors.accent,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Stack(
                        children: [
                          CircleAvatar(
                            radius: 50,
                            backgroundColor: AppColors.secondary,
                            backgroundImage: verificationSelfieUrl.isNotEmpty
                                ? MemoryImage(
                                    base64Decode(
                                      verificationSelfieUrl,
                                    ),
                                  )
                                : null,
                            child: verificationSelfieUrl.isEmpty
                                ? const Icon(
                                    Icons.person,
                                    size: 50,
                                  )
                                : null,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),
                    // NAME
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          fullName,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: AppColors.dark,
                          ),
                        ),
                        const SizedBox(width: 6),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // tags
                    const Text(
                      "Dietary Preferences",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),

                    const SizedBox(height: 10),

                    Wrap(
                      spacing: 8,
                      children: tags.isEmpty
                          ? [const Text("No preferences yet")]
                          : tags.map((tag) {
                              return Chip(
                                label: Text(tag),
                                backgroundColor: AppColors.secondary,
                              );
                            }).toList(),
                    ),

                    const SizedBox(height: 24),

                    const Text(
                      "Notification Settings",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SwitchListTile(
                      title: const Text(
                        "Pickup Reminders",
                      ),
                      value: pickupReminders,
                      onChanged: (value) async {
                        setState(() {
                          pickupReminders = value;
                        });

                        final user = FirebaseAuth.instance.currentUser;

                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(user!.uid)
                            .update({
                          'pickupReminders': value,
                        });
                      },
                    ),

                    SwitchListTile(
                      title: const Text(
                        "Dietary Match Alerts",
                      ),
                      value: itemAlerts,
                      onChanged: (value) async {
                        setState(() {
                          itemAlerts = value;
                        });

                        final user = FirebaseAuth.instance.currentUser;

                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(user!.uid)
                            .update({
                          'itemAlerts': value,
                        });
                      },
                    ),

                    const SizedBox(height: 20),

                    const Text(
                      "Discovery Settings",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 12),

                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: AppColors.accent.withOpacity(0.25),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            color: latitude != null
                                ? AppColors.accent
                                : Colors.grey,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  latitude == null
                                      ? "Location not set"
                                      : "Current Location",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  locationName.isEmpty
                                      ? "Use your current location"
                                      : locationName,
                                  style: TextStyle(
                                    color: AppColors.dark.withOpacity(0.7),
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 10),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            vertical: 14,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: getCurrentLocation,
                        icon: const Icon(
                          Icons.my_location,
                        ),
                        label: const Text(
                          "Update Location",
                        ),
                      ),
                    ),

                    const SizedBox(height: 14),

                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Discovery Radius: "
                          "${discoveryRadius.toInt()} km",
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Slider(
                          value: discoveryRadius,
                          min: 1,
                          max: 50,
                          divisions: 49,
                          label: "${discoveryRadius.toInt()} km",
                          onChanged: (value) {
                            setState(() {
                              discoveryRadius = value;
                            });
                          },
                          onChangeEnd: (value) async {
                            final user = FirebaseAuth.instance.currentUser;

                            await FirebaseFirestore.instance
                                .collection('users')
                                .doc(user!.uid)
                                .update({
                              'discoveryRadius': value,
                            });
                          },
                        ),
                      ],
                    ),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ProfileSetupScreen(),
                            ),
                          );

                          loadProfile();
                        },
                        child: const Text("Edit Profile"),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
