import 'package:flutter/material.dart';
import '../../core/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:my_app/providers/auth_provider.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  String? _loginError;

  late TabController _tabController;
  bool _obscureLogin = true;
  bool _obscureSignup = true;
  bool _obscureConfirm = true;

  final _loginFormKey = GlobalKey<FormState>();
  final _signupFormKey = GlobalKey<FormState>();

  final _loginEmailController = TextEditingController();
  final _loginPasswordController = TextEditingController();

  final _signupNameController = TextEditingController();
  final _signupEmailController = TextEditingController();
  final _signupPasswordController = TextEditingController();
  final _signupConfirmController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _loginEmailController.dispose();
    _loginPasswordController.dispose();
    _signupNameController.dispose();
    _signupEmailController.dispose();
    _signupPasswordController.dispose();
    _signupConfirmController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(String hint, IconData icon,
      {Widget? suffixIcon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle:
          TextStyle(color: AppColors.dark.withOpacity(0.4), fontSize: 14),
      prefixIcon: Icon(icon, color: AppColors.accent, size: 20),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.secondary, width: 1.5),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.secondary, width: 1.5),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.accent, width: 2),
      ),
    );
  }

  Widget _primaryButton(String label, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accent,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 2,
        ),
        onPressed: onPressed,
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.8,
          ),
        ),
      ),
    );
  }

  // ─── LOGIN TAB ──────────────────────────────────────────────────────────────
  Widget _loginTab() {
    return Form(
        key: _loginFormKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              const Text(
                "Welcome back!",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.dark,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Sign in to continue sharing food.",
                style: TextStyle(
                  fontSize: 13,
                  color: AppColors.dark.withOpacity(0.55),
                ),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _loginEmailController,
                keyboardType: TextInputType.emailAddress,
                decoration:
                    _inputDecoration("Email address", Icons.mail_outline),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Email is required";
                  }

                  if (!value.contains("@")) {
                    return "Enter a valid email";
                  }

                  return null;
                },
              ),

              const SizedBox(height: 14),
              TextFormField(
                controller: _loginPasswordController,
                obscureText: _obscureLogin,
                decoration: _inputDecoration(
                  "Password",
                  Icons.lock_outline,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscureLogin ? Icons.visibility_off : Icons.visibility,
                      color: AppColors.accent,
                      size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _obscureLogin = !_obscureLogin),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Password is required";
                  }

                  if (value.length < 8) {
                    return "Password must be at least 8 characters";
                  }

                  if (_loginError != null) {
                    return _loginError;
                  }

                  return null;
                },
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () async {
                    final authProvider = Provider.of<AuthProvider>(
                      context,
                      listen: false,
                    );

                    await authProvider.resetPassword(
                      context,
                      _loginEmailController.text.trim(),
                    );
                  },
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.accent,
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    "Forgot password?",
                    style: TextStyle(fontSize: 13),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // LOG IN BUTTON --------------------------------------------------------------------------

              _primaryButton("Log In", () async {
                setState(() {
                  _loginError = null;
                });

                if (!_loginFormKey.currentState!.validate()) {
                  return;
                }

                final authProvider =
                    Provider.of<AuthProvider>(context, listen: false);

                final error = await authProvider.signIn(
                  _loginEmailController.text.trim(),
                  _loginPasswordController.text.trim(),
                );

                if (!mounted) return;

                if (error != null) {
                  setState(() {
                    if (error == "invalid-credential") {
                      _loginError = "Incorrect email or password";
                    } else if (error == "user-not-found") {
                      _loginError = "Email not found";
                    } else {
                      _loginError = "Login Failed";
                    }
                  });

                  _loginFormKey.currentState!.validate();
                }
              }),
            ],
          ),
        ));
  }

  // ─── SIGN UP TAB ─────────────────────────────────────────────────────────────
  Widget _signupTab() {
    return Form(
        key: _signupFormKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              const Text(
                "Create account",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.dark,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Join the community. Share, connect, eat.",
                style: TextStyle(
                  fontSize: 13,
                  color: AppColors.dark.withOpacity(0.55),
                ),
              ),
              const SizedBox(height: 24),
              TextFormField(
                  controller: _signupNameController,
                  textCapitalization: TextCapitalization.words,
                  decoration:
                      _inputDecoration("Full name", Icons.person_outline),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "Name is required";
                    }
                    return null;
                  }),
              const SizedBox(height: 14),
              TextFormField(
                  controller: _signupEmailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration:
                      _inputDecoration("Email address", Icons.mail_outline),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return "Email is required";
                    }

                    if (!value.contains("@")) {
                      return "Enter a valid email";
                    }

                    return null;
                  }),
              const SizedBox(height: 14),
              TextFormField(
                controller: _signupPasswordController,
                obscureText: _obscureSignup,
                decoration: _inputDecoration(
                  "Password",
                  Icons.lock_outline,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscureSignup ? Icons.visibility_off : Icons.visibility,
                      color: AppColors.accent,
                      size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _obscureSignup = !_obscureSignup),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Password is required";
                  }

                  if (value.length < 8) {
                    return "Password must be at least 8 characters";
                  }

                  if (!RegExp(r'[A-Z]').hasMatch(value)) {
                    return "Password must contain an uppercase letter";
                  }

                  if (!RegExp(r'[a-z]').hasMatch(value)) {
                    return "Password must contain an lowercase letter";
                  }

                  if (!RegExp(r'[0-9]').hasMatch(value)) {
                    return "Password must contain a number";
                  }

                  if (!RegExp(r'[-_!@#$%^&*(),.?":{}|<>]').hasMatch(value)) {
                    return "Password must contain a special character";
                  }

                  return null;
                },
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _signupConfirmController,
                obscureText: _obscureConfirm,
                decoration: _inputDecoration(
                  "Confirm password",
                  Icons.lock_outline,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscureConfirm ? Icons.visibility_off : Icons.visibility,
                      color: AppColors.accent,
                      size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _obscureConfirm = !_obscureConfirm),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Please confirm your password";
                  }

                  if (value != _signupPasswordController.text) {
                    return "Passwords do not match";
                  }

                  return null;
                },
              ),
              const SizedBox(height: 24),

              // SIGN UP BUTTON --------------------------------------------------------------------------

              _primaryButton("Create Account", () async {
                if (!_signupFormKey.currentState!.validate()) {
                  return;
                }

                final authProvider =
                    Provider.of<AuthProvider>(context, listen: false);

                final error = await authProvider.signUp(
                  _signupEmailController.text.trim(),
                  _signupPasswordController.text.trim(),
                  _signupNameController.text.trim(),
                );

                if (!mounted) return;

                if (error != null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Sign-up failed: $error")),
                  );
                }
              }),
              Center(
                child: Text(
                  "By signing up, you agree to our Terms & Privacy Policy.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11,
                    color: AppColors.dark.withOpacity(0.45),
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      body: SafeArea(
        child: Column(
          children: [
            // ── HEADER ────────────────────────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 28),
              decoration: BoxDecoration(
                color: AppColors.accent,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(32),
                  bottomRight: Radius.circular(32),
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Image.asset(
                    "assets/images/white_logo.png",
                    height: 90,
                  ),
                  const SizedBox(height: 10),
                  const SizedBox(height: 4),
                  Text(
                    "Where surplus meets someone’s need.",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 13,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── TAB BAR ───────────────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 32),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.secondary.withOpacity(0.4),
                borderRadius: BorderRadius.circular(14),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: Colors.white,
                unselectedLabelColor: AppColors.dark.withOpacity(0.6),
                labelStyle: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: "Log In"),
                  Tab(text: "Sign Up"),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // ── TAB VIEWS ─────────────────────────────────────────────────────
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _loginTab(),
                  _signupTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
