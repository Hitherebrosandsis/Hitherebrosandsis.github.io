import 'package:firebase_auth/firebase_auth.dart' show FirebaseAuth;
import 'package:flutter/material.dart';
import 'package:my_app/screens/profile/profile_setup_screen.dart';
import 'package:provider/provider.dart';
import 'package:my_app/providers/auth_provider.dart';
import 'package:my_app/screens/home/home_screen.dart';
import 'auth_screen.dart';

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, _) {
        print("AUTH WRAPPER USER: ${authProvider.userObj}");

        final user = FirebaseAuth.instance.currentUser;
        
        if (user != null) {
          if (!authProvider.profileCompleted) {
            return const ProfileSetupScreen();
          }
          return const HomeScreen();
        } 
        return const AuthScreen();
      },
    );
  }
}