import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';
import '../../models/item_model.dart';
import '../../core/app_theme.dart';
import '../../services/notification_service.dart';

import 'package:random_string/random_string.dart';
import 'package:my_app/screens/item/qr_scanner.dart';
import 'qr_generator.dart';

Widget _buildImage(String imageUrl,
    {double height = 350, BoxFit fit = BoxFit.cover}) {
  if (imageUrl.isEmpty) {
    return Container(
      height: height,
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.secondary.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Center(child: Icon(Icons.image, size: 50)),
    );
  }
  try {
    final bytes = base64Decode(imageUrl);
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.memory(
        bytes,
        height: height,
        width: double.infinity,
        fit: fit,
        errorBuilder: (_, __, ___) => Container(
          height: height,
          color: Colors.grey[300],
          child: const Center(child: Icon(Icons.broken_image, size: 40)),
        ),
      ),
    );
  } catch (_) {
    return Container(
      height: height,
      color: Colors.grey[300],
      child: const Center(child: Icon(Icons.broken_image, size: 40)),
    );
  }
}

// ─── Map section (OpenStreetMap via flutter_map — no API key needed) ─────────
class _ItemMapSection extends StatelessWidget {
  final double latitude;
  final double longitude;
  final String title;

  const _ItemMapSection({
    required this.latitude,
    required this.longitude,
    required this.title,
  });

  LatLng get _position => LatLng(latitude, longitude);

  Future<void> _openInMaps() async {
    // Opens Google Maps website/app centered on the pin
    final uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _getDirections() async {
    // Opens Google Maps navigation to the item
    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude&travelmode=driving',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Row(
          children: [
            const Icon(Icons.map, size: 18, color: Colors.green),
            const SizedBox(width: 6),
            Text(
              "Item Location",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
                color: AppColors.dark,
              ),
            ),
          ],
        ),

        const SizedBox(height: 8),

        // OpenStreetMap tile map
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            height: 210,
            child: FlutterMap(
              options: MapOptions(
                initialCenter: _position,
                initialZoom: 16.5,
                interactionOptions: const InteractionOptions(
                  flags: InteractiveFlag.pinchZoom | InteractiveFlag.drag,
                ),
              ),
              children: [
                // CartoDB Positron — free, no API key, allows app usage
                TileLayer(
                  urlTemplate:
                      'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png',
                  subdomains: const ['a', 'b', 'c', 'd'],
                  userAgentPackageName: 'com.example.app',
                  maxZoom: 19,
                ),
                // Marker pinned at item location
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _position,
                      width: 48,
                      height: 48,
                      child: const Icon(
                        Icons.location_pin,
                        color: Colors.red,
                        size: 48,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 10),

        // Action buttons
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.open_in_new, size: 16),
                label: const Text("Open in Maps"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.blue,
                  side: const BorderSide(color: Colors.blue),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: _openInMaps,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.directions, size: 16),
                label: const Text("Get Directions"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: _getDirections,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Main screen ─────────────────────────────────────────────────────────────
class ItemDetailScreen extends StatefulWidget {
  final ItemModel item;

  const ItemDetailScreen({super.key, required this.item});

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  bool isProcessing = false;

  String getTimeRemaining(DateTime expiration) {
    final now = DateTime.now();
    if (expiration.isBefore(now)) {
      return "Expired";
    }
    final diff = expiration.difference(now);
    final hours = diff.inHours;
    final minutes = diff.inMinutes % 60;
    return "Expires in " "${hours}h ${minutes}m";
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    final isOwner = currentUser?.uid == widget.item.ownerId;
    final isExpired = widget.item.expirationDate.isBefore(DateTime.now());
    final hasLocation =
        widget.item.latitude != null && widget.item.longitude != null;

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('items')
          .doc(widget.item.id)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        final updatedItem = ItemModel.fromFirestore(
          snapshot.data!.data() as Map<String, dynamic>,
          snapshot.data!.id,
        );

        return Scaffold(
          backgroundColor: AppColors.base,
          appBar: AppBar(
            backgroundColor: AppColors.accent,
            title: Text(updatedItem.title),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Item image
                _buildImage(updatedItem.imageUrl),

                const SizedBox(height: 16),

                Text(
                  updatedItem.title,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppColors.dark,
                  ),
                ),

                const SizedBox(height: 8),

                // Status badge
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: isExpired
                            ? AppColors.danger.withOpacity(0.2)
                            : updatedItem.status == 'available'
                                ? AppColors.success.withOpacity(0.2)
                                : updatedItem.status == 'completed'
                                    ? AppColors.danger.withOpacity(0.2)
                                    : AppColors.warning.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        isExpired ? "expired" : updatedItem.status,
                        style: TextStyle(
                          color: isExpired
                              ? AppColors.danger
                              : updatedItem.status == 'available'
                                  ? AppColors.success
                                  : updatedItem.status == 'completed'
                                      ? AppColors.danger
                                      : AppColors.warning,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Owner
                Row(
                  children: [
                    const Icon(Icons.person, size: 18),
                    const SizedBox(width: 6),
                    Text(
                      updatedItem.ownerName,
                      style: TextStyle(
                        color: AppColors.dark.withOpacity(0.6),
                      ),
                    ),
                  ],
                ),

                if (isOwner && updatedItem.requestedBy != null)
                  FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance
                        .collection('users')
                        .doc(updatedItem.requestedBy)
                        .get(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const SizedBox();
                      }

                      final requesterData =
                          snapshot.data!.data() as Map<String, dynamic>?;

                      final requesterName =
                          requesterData?['fullName'] ?? 'Unknown User';

                      return Padding(
                        padding: const EdgeInsets.only(
                          top: 10,
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.shopping_bag,
                              size: 18,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              "Requested by: $requesterName",
                              style: TextStyle(
                                color: AppColors.dark.withOpacity(0.7),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                const SizedBox(height: 24),

                // Description
                Text(
                  updatedItem.description,
                  style: TextStyle(
                    fontSize: 14,
                    color: AppColors.dark.withOpacity(0.7),
                  ),
                ),

                const SizedBox(height: 16),

                // Tags
                if (updatedItem.tags.isNotEmpty)
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: updatedItem.tags.map((tag) {
                      return Chip(
                        label: Text(tag),
                        backgroundColor: AppColors.secondary,
                      );
                    }).toList(),
                  ),

                const SizedBox(height: 8),

                if (updatedItem.status == 'reserved' &&
                    (isOwner || updatedItem.requestedBy == currentUser?.uid))
                  Container(
                    margin: const EdgeInsets.only(top: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.schedule,
                          color: AppColors.success,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            "Pickup Time: "
                            "${updatedItem.pickupTime.month}/"
                            "${updatedItem.pickupTime.day}/"
                            "${updatedItem.pickupTime.year} • "
                            "${TimeOfDay.fromDateTime(updatedItem.pickupTime).format(context)}",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.success,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                if (updatedItem.status == 'reserved')
                  const SizedBox(height: 16),

                // Expiry timer
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: isExpired
                        ? AppColors.danger.withOpacity(0.15)
                        : AppColors.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: isExpired ? AppColors.danger : AppColors.accent,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          isExpired
                              ? "Expired"
                              : getTimeRemaining(updatedItem.expirationDate),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color:
                                isExpired ? AppColors.danger : AppColors.accent,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Location address label
                if (updatedItem.locationName != null &&
                    updatedItem.locationName!.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.success.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on,
                            color: AppColors.success, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            updatedItem.locationName!,
                            style: const TextStyle(
                              color: AppColors.success,
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 16),

                // OSM Map + buttons (only if coordinates exist)
                if (hasLocation) ...[
                  _ItemMapSection(
                    latitude: updatedItem.latitude!,
                    longitude: updatedItem.longitude!,
                    title: updatedItem.title,
                  ),
                  const SizedBox(height: 16),
                ],
              ],
            ),
          ),

          // action buttons
          bottomNavigationBar: SafeArea(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Builder(
                builder: (context) {
                  final isRequester =
                      updatedItem.requestedBy == currentUser?.uid;

                  // for owners
                  if (isOwner) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // accept + reject
                        if (updatedItem.status == 'requested' && !isExpired)
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                    foregroundColor: Colors.white,
                                  ),
                                  onPressed: isProcessing
                                      ? null
                                      : () async {
                                          setState(() {
                                            isProcessing = true;
                                          });
                                          final freshDoc =
                                              await FirebaseFirestore.instance
                                                  .collection('items')
                                                  .doc(updatedItem.id)
                                                  .get();

                                          final freshData = freshDoc.data();

                                          if (freshData?['status'] !=
                                              'requested') {
                                            if (!context.mounted) {
                                              setState(() {
                                                isProcessing = false;
                                              });

                                              return;
                                            }

                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                  "Request already handled.",
                                                ),
                                              ),
                                            );
                                            return;
                                          }
                                          // pick date
                                          final pickedDate =
                                              await showDatePicker(
                                            context: context,
                                            initialDate: DateTime.now(),
                                            firstDate: DateTime.now(),
                                            lastDate: updatedItem.expirationDate
                                                .subtract(
                                              const Duration(hours: 1),
                                            ),
                                          );

                                          if (pickedDate == null) {
                                            setState(() {
                                              isProcessing = false;
                                            });
                                            return;
                                          }

                                          // pick time
                                          final pickedTime =
                                              await showTimePicker(
                                            context: context,
                                            initialTime: TimeOfDay.now(),
                                          );

                                          if (pickedTime == null) {
                                            setState(() {
                                              isProcessing = false;
                                            });
                                            return;
                                          }

                                          // combine date + time
                                          final pickupDateTime = DateTime(
                                            pickedDate.year,
                                            pickedDate.month,
                                            pickedDate.day,
                                            pickedTime.hour,
                                            pickedTime.minute,
                                          );

                                          final minimumPickupTime =
                                              DateTime.now().add(
                                            const Duration(hours: 1),
                                          );

                                          if (pickupDateTime
                                              .isBefore(minimumPickupTime)) {
                                            if (!context.mounted) return;

                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                  "Pickup time must be at least 1 hour from now.",
                                                ),
                                              ),
                                            );

                                            setState(() {
                                              isProcessing = false;
                                            });

                                            return;
                                          }

                                          if (pickupDateTime.isAfter(
                                            updatedItem.expirationDate.subtract(
                                              const Duration(hours: 1),
                                            ),
                                          )) {
                                            if (!context.mounted) return;

                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                  "Pickup time must be at least 1 hour before expiration.",
                                                ),
                                              ),
                                            );
                                            return;
                                          }

                                          // save to firestore
                                          await FirebaseFirestore.instance
                                              .collection('items')
                                              .doc(updatedItem.id)
                                              .update({
                                            'status': 'reserved',
                                            'pickupTime': Timestamp.fromDate(
                                              pickupDateTime,
                                            ),
                                            'receiverId':
                                                updatedItem.requestedBy,
                                            'qrUsed': false,
                                          });
                                          await NotificationService
                                              .createNotification(
                                            userId: updatedItem.requestedBy!,
                                            title: "Pickup Reminder",
                                            body:
                                                "Pickup for ${updatedItem.title} is scheduled at "
                                                "${pickupDateTime.month}/"
                                                "${pickupDateTime.day}/"
                                                "${pickupDateTime.year} • "
                                                "${TimeOfDay.fromDateTime(pickupDateTime).format(context)}",
                                            type: "pickup_reminder",
                                            itemId: updatedItem.id,
                                          );

                                          await NotificationService
                                              .createNotification(
                                            userId: updatedItem.ownerId,
                                            title: "Pickup Reminder",
                                            body:
                                                "Pickup for ${updatedItem.title} is scheduled at "
                                                "${pickupDateTime.month}/"
                                                "${pickupDateTime.day}/"
                                                "${pickupDateTime.year} • "
                                                "${TimeOfDay.fromDateTime(pickupDateTime).format(context)}",
                                            type: "pickup_reminder",
                                            itemId: updatedItem.id,
                                          );

                                          await NotificationService
                                              .createNotification(
                                            userId: updatedItem.requestedBy!,
                                            title: "Request Accepted",
                                            body:
                                                "Your request for ${updatedItem.title} was accepted.\nPickup: ${pickedDate.month}/${pickedDate.day} ${pickedTime.format(context)}",
                                            type: "accepted",
                                            itemId: updatedItem.id,
                                          );

                                          await NotificationService
                                              .createNotification(
                                            userId: updatedItem.requestedBy!,
                                            title: "Pickup Scheduled",
                                            body:
                                                "Pickup for ${updatedItem.title} is scheduled at "
                                                "${pickupDateTime.month}/"
                                                "${pickupDateTime.day}/"
                                                "${pickupDateTime.year} • "
                                                "${TimeOfDay.fromDateTime(pickupDateTime).format(context)}",
                                            type: "pickup_reminder",
                                            itemId: updatedItem.id,
                                          );

                                          // scheduled reminder
                                          await NotificationService
                                              .schedulePickupReminder(
                                            title: "Pickup Reminder",
                                            body:
                                                "${updatedItem.title} pickup is at "
                                                "${pickupDateTime.month}/"
                                                "${pickupDateTime.day} • "
                                                "${TimeOfDay.fromDateTime(pickupDateTime).format(context)} "
                                                "(1 hour remaining)",
                                            pickupTime: pickupDateTime,
                                            itemId: updatedItem.id,
                                          );

                                          if (!context.mounted) return;

                                          setState(() {
                                            isProcessing = false;
                                          });
                                        },
                                  child: const Text(
                                    "Accept",
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red,
                                    foregroundColor: Colors.white,
                                  ),
                                  onPressed: isProcessing
                                      ? null
                                      : () async {
                                          setState(() {
                                            isProcessing = true;
                                          });
                                          await FirebaseFirestore.instance
                                              .collection('items')
                                              .doc(updatedItem.id)
                                              .update({
                                            'status': 'available',
                                            'requestedBy': null,
                                          });
                                          final requesterId =
                                              updatedItem.requestedBy;
                                          await NotificationService
                                              .createNotification(
                                            userId: requesterId!,
                                            title: "Request Rejected",
                                            body:
                                                "Your request for ${updatedItem.title} was rejected.",
                                            type: "rejected",
                                            itemId: updatedItem.id,
                                          );
                                          Navigator.pop(context);
                                        },
                                  child: const Text(
                                    "Reject",
                                  ),
                                ),
                              ),
                            ],
                          ),

                        // completed
                        if (updatedItem.status == 'reserved' && !isExpired)
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () async {
                                await FirebaseFirestore.instance
                                    .collection('items')
                                    .doc(updatedItem.id)
                                    .update({
                                  'qrCodeString': randomString(20),
                                  'qrUsed': false,
                                });

                                String qrCodeString = (await FirebaseFirestore
                                    .instance
                                    .collection('items')
                                    .doc(updatedItem.id)
                                    .get())['qrCodeString'];

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => QrGeneratorScreen(
                                        item: updatedItem,
                                        qrCodeString: qrCodeString),
                                  ),
                                );
                              },
                              child: const Text(
                                "Mark as Completed",
                              ),
                            ),
                          ),

                        const SizedBox(height: 10),

                        // back to listings
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.secondary,
                              foregroundColor: Colors.black,
                            ),
                            onPressed: () => Navigator.pop(context),
                            child: const Text(
                              "Back",
                            ),
                          ),
                        ),
                      ],
                    );
                  }

                  // requesters
                  if (!isExpired &&
                      updatedItem.status == 'available' &&
                      updatedItem.requestedBy == null) {
                    return SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            vertical: 14,
                          ),
                        ),
                        onPressed: () async {
                          final requesterDoc = await FirebaseFirestore.instance
                              .collection('users')
                              .doc(currentUser!.uid)
                              .get();

                          // pending requests count
                          final pendingRequests =
                              await FirebaseFirestore.instance
                                  .collection('items')
                                  .where(
                                    'requestedBy',
                                    isEqualTo: currentUser.uid,
                                  )
                                  .where(
                                    'status',
                                    isEqualTo: 'requested',
                                  )
                                  .get();

                          // reserved items count
                          final reservedItems = await FirebaseFirestore.instance
                              .collection('items')
                              .where(
                                'requestedBy',
                                isEqualTo: currentUser.uid,
                              )
                              .where(
                                'status',
                                isEqualTo: 'reserved',
                              )
                              .get();

                          // if they have 5 pending requests already, they can't request more until some are accepted/rejected OR cancelled
                          if (pendingRequests.docs.length >= 5) {
                            if (!context.mounted) return;

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  "You can only have 5 pending requests.",
                                ),
                              ),
                            );

                            return;
                          }

                          // if they have 3 reserved items already, they can't request more until they completed or the time for pickup passes
                          if (reservedItems.docs.length >= 3) {
                            if (!context.mounted) return;

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  "You can only reserve 3 items at a time.",
                                ),
                              ),
                            );

                            return;
                          }

                          await FirebaseFirestore.instance
                              .collection('items')
                              .doc(updatedItem.id)
                              .update({
                            'status': 'requested',
                            'requestedBy': currentUser.uid,
                          });
                          final requesterName =
                              requesterDoc.data()?['fullName'] ?? "Someone";

                          await NotificationService.createNotification(
                            userId: updatedItem.ownerId,
                            title: "New Request",
                            body:
                                "$requesterName requested ${updatedItem.title}.",
                            type: "request",
                            itemId: updatedItem.id,
                          );

                          Navigator.pop(context);

                          if (!context.mounted) return;
                        },
                        child: const Text("Request Item"),
                      ),
                    );
                  }

                  // reserved
                  if (updatedItem.status == 'reserved' && isRequester) {
                    final pickup = updatedItem.pickupTime;

                    final now = DateTime.now();

                    final difference = pickup.difference(now);

                    String countdownText;

                    if (difference.inMinutes <= 0) {
                      countdownText = "Pickup time passed";
                    } else if (difference.inHours < 1) {
                      countdownText = "Pickup in "
                          "${difference.inMinutes} mins";
                    } else {
                      countdownText = "Pickup in "
                          "${difference.inHours}h "
                          "${difference.inMinutes % 60}m";
                    }

                    final today = DateTime.now();

                    final isToday = pickup.year == today.year &&
                        pickup.month == today.month &&
                        pickup.day == today.day;

                    final tomorrow = today.add(
                      const Duration(days: 1),
                    );

                    final isTomorrow = pickup.year == tomorrow.year &&
                        pickup.month == tomorrow.month &&
                        pickup.day == tomorrow.day;

                    const weekdays = [
                      '',
                      'Mon',
                      'Tue',
                      'Wed',
                      'Thu',
                      'Fri',
                      'Sat',
                      'Sun',
                    ];

                    String pickupLabel;

                    if (isToday) {
                      pickupLabel = "Pickup Today • "
                          "${TimeOfDay.fromDateTime(pickup).format(context)}";
                    } else if (isTomorrow) {
                      pickupLabel = "Pickup Tomorrow • "
                          "${TimeOfDay.fromDateTime(pickup).format(context)}";
                    } else {
                      pickupLabel = "Pickup "
                          "${pickup.month}/${pickup.day} "
                          "(${weekdays[pickup.weekday]}) • "
                          "${TimeOfDay.fromDateTime(pickup).format(context)}";
                    }

                    return Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        vertical: 16,
                        horizontal: 18,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.success.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: AppColors.success.withOpacity(0.25),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.schedule,
                                color: AppColors.success,
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  pickupLabel,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.success,
                                    fontSize: 15,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            countdownText,
                            style: TextStyle(
                              color: AppColors.dark.withOpacity(0.7),
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 8),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              icon: const Icon(Icons.qr_code_scanner),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.success,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 14,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => QrScannerScreen(),
                                    settings: RouteSettings(
                                      arguments: updatedItem,
                                    ),
                                  ),
                                );
                              },
                              label: const Text(
                                "Scan QR Code",
                              ),
                            ),
                          )
                        ],
                      ),
                    );
                  }

                  // cancel request
                  if (updatedItem.status == 'requested' && isRequester) {
                    return ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        await FirebaseFirestore.instance
                            .collection('items')
                            .doc(updatedItem.id)
                            .update({
                          'status': 'available',
                          'requestedBy': null,
                        });
                        Navigator.pop(context);
                      },
                      child: const Text("Cancel Request"),
                    );
                  }

                  String statusText;
                  switch (updatedItem.status) {
                    case 'available':
                      statusText = 'Available';
                      break;
                    case 'requested':
                      statusText = 'Requested';
                      break;
                    case 'reserved':
                      statusText = 'Reserved';
                      break;

                    case 'completed':
                      statusText = 'Completed';
                      break;

                    default:
                      statusText = updatedItem.status;
                  }

                  return ElevatedButton(
                    onPressed: null,
                    child: Text(statusText),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
}
