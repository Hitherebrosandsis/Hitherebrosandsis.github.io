import 'package:flutter/material.dart';
import '../../models/item_model.dart';
import '../../core/app_theme.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:qr_flutter/qr_flutter.dart';

class QrGeneratorScreen extends StatefulWidget {
  final ItemModel item;
  final String qrCodeString;

  const QrGeneratorScreen(
      {super.key, required this.qrCodeString, required this.item});

  @override
  State<QrGeneratorScreen> createState() => _QrGeneratorScreenState();
}

class _QrGeneratorScreenState extends State<QrGeneratorScreen> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('items')
          .doc(widget.item.id)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Text("Error: ${snapshot.error}"),
          );
        }

        if (!snapshot.hasData || snapshot.data?.data() == null) {
          return const Center(
            child: Text("Item not found"),
          );
        }

        final gatheredItem = snapshot.data!.data() as Map<String, dynamic>;

        if (gatheredItem['status'] == "completed") {
          return Scaffold(
            backgroundColor: AppColors.base,
            appBar: AppBar(
              backgroundColor: AppColors.accent,
              title: Text(gatheredItem['title']),
            ),
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.check_circle_outline,
                    size: 150,
                    color: Colors.green[400],
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Completed",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "You may leave this screen now",
                  ),
                ],
              ),
            ),
          );
        }

        if (gatheredItem['qrUsed'] == true) {
          return Scaffold(
            backgroundColor: AppColors.base,
            appBar: AppBar(
              backgroundColor: AppColors.accent,
              title: Text(widget.item.title),
            ),
            body: const Center(
              child: Text(
                "This QR Code has already been used",
              ),
            ),
          );
        }

        return Scaffold(
          backgroundColor: AppColors.base,
          appBar: AppBar(
            backgroundColor: AppColors.accent,
            title: Text(widget.item.title),
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  QrImageView(
                    data: widget.qrCodeString,
                    size: 250,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Let your customer scan this QR code",
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
