import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/app_theme.dart';
import 'dart:io';
import 'dart:convert';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import '../../widgets/tag_chip.dart';
import '../../services/notification_service.dart';

class PostItemScreen extends StatefulWidget {
  const PostItemScreen({super.key});

  @override
  State<PostItemScreen> createState() => _PostItemScreenState();
}

class _PostItemScreenState extends State<PostItemScreen> {
  final titleController = TextEditingController();
  final descController = TextEditingController();

  final Map<String, List<String>> tagCategories = {
    "Dietary": ["Vegan", "Vegetarian", "Halal", "Keto", "Gluten-Free"],
    "Food Type": [
      "Home-Cooked",
      "Raw Ingredients",
      "Cooked Meals",
      "Snacks",
      "Beverages"
    ],
    "Allergens": ["Dairy-Free", "Nut-Free", "Seafood-Free"],
  };

  List<String> selectedTags = [];
  bool isLoading = false;
  File? _image;
  String? _base64Image;
  final picker = ImagePicker();
  DateTime? expirationDate;

  double? _latitude;
  double? _longitude;
  String? _locationName;
  bool _isFetchingLocation = false;

  @override
  void initState() {
    super.initState();
    _fetchLocation(); // automatically grab location on screen open
  }

  @override
  void dispose() {
    titleController.dispose();
    descController.dispose();
    super.dispose();
  }

  Future<void> _fetchLocation() async {
    setState(() => _isFetchingLocation = true);

    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever ||
          permission == LocationPermission.denied) {
        setState(() => _isFetchingLocation = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text(
                    "Location permission denied. Item will be posted without location.")),
          );
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition();

      String locationLabel = '';
      try {
        final placemarks = await placemarkFromCoordinates(
          position.latitude,
          position.longitude,
        );
        if (placemarks.isNotEmpty) {
          final p = placemarks.first;
          final parts = [
            if (p.subThoroughfare != null && p.subThoroughfare!.isNotEmpty)
              p.subThoroughfare!,
            if (p.thoroughfare != null && p.thoroughfare!.isNotEmpty)
              p.thoroughfare!,
            if (p.subLocality != null && p.subLocality!.isNotEmpty)
              p.subLocality!,
            if (p.locality != null && p.locality!.isNotEmpty) p.locality!,
          ];
          locationLabel = parts.isNotEmpty
              ? parts.join(', ')
              : '${position.latitude.toStringAsFixed(5)}, ${position.longitude.toStringAsFixed(5)}';
        }
      } catch (_) {
        locationLabel =
            '${position.latitude.toStringAsFixed(5)}, ${position.longitude.toStringAsFixed(5)}';
      }

      setState(() {
        _latitude = position.latitude;
        _longitude = position.longitude;
        _locationName = locationLabel;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not get location: ${e.toString()}")),
        );
      }
    } finally {
      setState(() => _isFetchingLocation = false);
    }
  }

  Future<void> pickImage() async {
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 50,
      maxWidth: 800,
    );

    if (picked != null) {
      final file = File(picked.path);
      final bytes = await file.readAsBytes();
      setState(() {
        _image = file;
        _base64Image = base64Encode(bytes);
      });
    }
  }

  Future<void> pickExpirationDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );

    if (picked != null) {
      setState(() {
        expirationDate = DateTime(
          picked.year,
          picked.month,
          picked.day,
          23,
          59,
          59,
        );
      });
    }
  }

  Future<void> postItem() async {
    if (selectedTags.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Select at least one category")),
      );
      return;
    }

    if (titleController.text.isEmpty ||
        descController.text.isEmpty ||
        _base64Image == null ||
        expirationDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please complete all fields")),
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception("User not logged in");

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      final fullName = userDoc['fullName'];

      final itemRef = await FirebaseFirestore.instance.collection('items').add({
        'title': titleController.text.trim(),
        'description': descController.text.trim(),
        'ownerId': user.uid,
        'ownerName': fullName,
        'imageUrl': _base64Image,
        'status': 'available',
        'requestedBy': null,
        'createdAt': Timestamp.now(),
        'expirationDate': Timestamp.fromDate(expirationDate!),
        'tags': selectedTags,
        'latitude': _latitude,
        'longitude': _longitude,
        'locationName': _locationName,
      });

      final users = await FirebaseFirestore.instance.collection('users').get();

      for (var userDoc in users.docs) {
        // skip current user
        if (userDoc.id == user.uid) continue;

        final userTags = List<String>.from(
          userDoc.data()['tags'] ?? [],
        );

        final alertsEnabled = userDoc.data()['itemAlerts'] ?? true;

        final hasMatch = selectedTags.any(
          (tag) => userTags.contains(tag),
        );

        final userLat = (userDoc.data()['latitude'] ?? 0).toDouble();

        final userLng = (userDoc.data()['longitude'] ?? 0).toDouble();

        final discoveryRadius =
            (userDoc.data()['discoveryRadius'] ?? 50).toDouble();

// skip users without location
        if (userLat == 0 ||
            userLng == 0 ||
            _latitude == null ||
            _longitude == null) {
          continue;
        }

        final distance = Geolocator.distanceBetween(
              userLat,
              userLng,
              _latitude!,
              _longitude!,
            ) /
            1000;

        final withinRadius = distance <= discoveryRadius;

        if (hasMatch && alertsEnabled && withinRadius) {
          await NotificationService.createNotification(
              userId: userDoc.id,
              title: "New Matching Item",
              body:
                  "${titleController.text.trim()} matches your dietary preferences "
                  "(${distance.toStringAsFixed(1)} km away).",
              type: "dietary_match",
              itemId: itemRef.id);
        }
      }

      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: ${e.toString()}")),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Post Item"),
        backgroundColor: AppColors.accent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Image picker
            GestureDetector(
              onTap: pickImage,
              child: Container(
                height: 350,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _image == null
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.camera_alt, color: AppColors.dark),
                          const SizedBox(height: 8),
                          const Text("Tap to take photo"),
                        ],
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.file(_image!, fit: BoxFit.cover),
                      ),
              ),
            ),

            const SizedBox(height: 20),

            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Title"),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descController,
              decoration: const InputDecoration(labelText: "Description"),
              maxLines: 3,
            ),

            const SizedBox(height: 16),

            // Location tile
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.blue.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  _isFetchingLocation
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(
                          _latitude != null
                              ? Icons.location_on
                              : Icons.location_off,
                          color: _latitude != null ? Colors.blue : Colors.grey,
                        ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _isFetchingLocation
                          ? "Getting your location..."
                          : _locationName != null && _locationName!.isNotEmpty
                              ? _locationName!
                              : "Location unavailable",
                      style: TextStyle(
                        color: _latitude != null ? AppColors.dark : Colors.grey,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  // Retry button
                  if (!_isFetchingLocation)
                    IconButton(
                      icon: const Icon(Icons.refresh, size: 20),
                      onPressed: _fetchLocation,
                      tooltip: "Retry location",
                      color: Colors.blue,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Categories",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: tagCategories.entries.map((entry) {
                final category = entry.key;
                final tags = entry.value;

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: AppColors.dark,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: tags.map((tag) {
                        return TagChip(
                          label: tag,
                          selected: selectedTags.contains(tag),
                          onSelected: (val) {
                            setState(() {
                              if (val) {
                                selectedTags.add(tag);
                              } else {
                                selectedTags.remove(tag);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                  ],
                );
              }).toList(),
            ),

            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(
                expirationDate == null
                    ? "Select Expiration Date"
                    : "Expires: ${expirationDate!.toLocal().toString().split(' ')[0]}",
                style: TextStyle(color: AppColors.dark),
              ),
              trailing: const Icon(Icons.calendar_today),
              onTap: pickExpirationDate,
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
              ),
            ],
          ),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  vertical: 16,
                ),
              ),
              onPressed: isLoading ? null : postItem,
              child: isLoading
                  ? const CircularProgressIndicator(
                      color: Colors.white,
                    )
                  : const Text(
                      "Post Item",
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
