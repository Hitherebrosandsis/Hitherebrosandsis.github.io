import 'package:flutter/material.dart';
import '../../models/item_model.dart';
import '../../core/app_theme.dart';
import 'dart:async';

import 'package:mobile_scanner/mobile_scanner.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:firebase_auth/firebase_auth.dart';
import '../../services/notification_service.dart';

class QrScannerScreen extends StatefulWidget {
  const QrScannerScreen({super.key});

  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen>
    with WidgetsBindingObserver {
  MobileScannerController qrScannercontroller = MobileScannerController(
    autoStart: false,
  );
  Barcode? _barcode;

  bool hasCompleted = false;
  bool scanSuccess = false;

  Future<void> completeTransaction(ItemModel item) async {
    if (hasCompleted) return;

    hasCompleted = true;
    scanSuccess = true;
    await FirebaseFirestore.instance.collection('items').doc(item.id).update({
      'status': 'completed',
      'qrUsed': true,
    });

    await NotificationService.createNotification(
      userId: item.requestedBy!,
      title: "Pickup Completed",
      body: "${item.title} has been marked completed.",
      type: "completed",
      itemId: item.id,
    );

    // Notification to poster/owner
    await NotificationService.createNotification(
      userId: item.ownerId,
      title: "Item Successfully Handed Off",
      body: "You successfully completed the handoff for ${item.title}.",
      type: "completed",
      itemId: item.id,
    );
  }

  StreamSubscription<Object?>? _subscription;
  //pauses the scanner if app is paused

  void didChangeAppLifecycleState(AppLifecycleState state) {
    // If the controller is not ready, do not try to start or stop it.
    // Permission dialogs can trigger lifecycle changes before the controller is ready.
    if (!qrScannercontroller.value.hasCameraPermission) {
      return;
    }

    switch (state) {
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
        return;
      case AppLifecycleState.resumed:
        // Restart the scanner when the app is resumed.
        // Don't forget to resume listening to the barcode events.
        _subscription = qrScannercontroller.barcodes.listen(_handleBarcode);
        unawaited(qrScannercontroller.start());
        break;

      case AppLifecycleState.inactive:
        // Stop the scanner when the app is paused.
        // Also stop the barcode events subscription.
        unawaited(_subscription?.cancel());
        _subscription = null;
        unawaited(qrScannercontroller.stop());
    }
  }

  void _handleBarcode(BarcodeCapture barcodes) {
    if (mounted) {
      setState(() {
        _barcode = barcodes.barcodes.firstOrNull;
        unawaited(qrScannercontroller.stop());
      });
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _subscription = qrScannercontroller.barcodes.listen(_handleBarcode);
    unawaited(qrScannercontroller.start());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    qrScannercontroller.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    ItemModel item = ModalRoute.of(context)!.settings.arguments as ItemModel;

    return StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('items')
            .doc(item.id)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }
          if (!snapshot.hasData) {
            return const Center(
              child: Text("Waiting for Item"),
            );
          }

          final gatheredItem = snapshot.data!.data() as Map<String, dynamic>;

          if (scanSuccess) {
            return Scaffold(
              backgroundColor: AppColors.base,
              appBar: AppBar(
                backgroundColor: AppColors.accent,
                title: Text(item.title),
              ),
              body: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      Icon(
                        Icons.check_circle_outline,
                        size: 150,
                        color: Colors.green[400],
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Completed",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "You may leave this screen now",
                      ),
                    ],
                  )
                ],
              ),
            );
          }

          final currentUserId = FirebaseAuth.instance.currentUser!.uid;

          // if the item is completed or the one scanning is not the receiver, show error message
          if (currentUserId != gatheredItem['receiverId']) {
            return Scaffold(
              backgroundColor: AppColors.base,
              appBar: AppBar(
                backgroundColor: AppColors.accent,
                title: Text(item.title),
              ),
              body: const Center(
                child: Text(
                  "You are not authorized to claim this item",
                ),
              ),
            );
          }

          final String? qrCodeString = gatheredItem['qrCodeString'];

          if (qrCodeString == null) {
            // return const Center(
            //   child: Text("Wait for the Giver to provide your QR Code"),
            // );
            return Scaffold(
                backgroundColor: AppColors.base,
                appBar: AppBar(
                  backgroundColor: AppColors.accent,
                  title: Text(item.title),
                ),
                body: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: 20),
                        Icon(Icons.question_mark_rounded, size: 150),
                        SizedBox(height: 20),
                        Text(
                          "No QR code provided",
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 20),
                        Text(
                            "Leave this screen now and wait for\nthe Owner to provide the QR Code")
                      ],
                    )
                  ],
                )

                // const Column(
                //   crossAxisAlignment: CrossAxisAlignment.center,
                //   children: [
                //     const SizedBox(height: 20),
                //     Icon(Icons.question_mark_rounded, size: 150),
                //     const SizedBox(height: 20),
                //     Text("No QR code provided", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),
                //     const SizedBox(height: 20),
                //     Text("Leave this screen now and wait for the Owner to provide the QR Code")
                //   ],
                // )
                );
          }

          if (_barcode == null) {
            return Scaffold(
                backgroundColor: AppColors.base,
                appBar: AppBar(
                  backgroundColor: AppColors.accent,
                  title: Text(item.title),
                ),
                body: Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox.square(
                              dimension: 300,
                              child: MobileScanner(
                                  controller: qrScannercontroller,
                                  onDetect: _handleBarcode),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              "Scan the QR Code provided by the Owner",
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold),
                            )
                          ],
                        )
                      ],
                    )));
          } else {
            if (_barcode!.rawValue != qrCodeString) {
              return Scaffold(
                  backgroundColor: AppColors.base,
                  appBar: AppBar(
                    backgroundColor: AppColors.accent,
                    title: Text(item.title),
                  ),
                  body: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(height: 20),
                          Icon(Icons.cancel_outlined,
                              size: 150, color: Colors.red[900]),
                          const SizedBox(height: 20),
                          Text(
                            "Wrong QR Code!!!",
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 20),
                          Text("Leave this screen now and retry the QR Scanner")
                        ],
                      )
                    ],
                  ));
            } else {
              if (!scanSuccess) {
                scanSuccess = true;
                completeTransaction(item);
              }

              return Scaffold(
                  backgroundColor: AppColors.base,
                  appBar: AppBar(
                    backgroundColor: AppColors.accent,
                    title: Text(item.title),
                  ),
                  body: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(height: 20),
                          Icon(Icons.check_circle_outline,
                              size: 150, color: Colors.green[400]),
                          const SizedBox(height: 20),
                          Text(
                            "Completed",
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 20),
                          Text("You may leave this screen now")
                        ],
                      )
                    ],
                  )

                  // Column(
                  //   crossAxisAlignment: CrossAxisAlignment.center,
                  //   children: [
                  //     const SizedBox(height: 20),
                  //     Icon(Icons.check_circle_outline, size: 150, color: Colors.green[400]),
                  //     const SizedBox(height: 20),
                  //     Text("Completed", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),
                  //     const SizedBox(height: 20),
                  //     Text("You may leave this screen now")
                  //   ],
                  // )

                  // const Padding(
                  //   padding: EdgeInsets.all(16),
                  //   child: Text("completed")
                  // )
                  );
            }
          }
        });
  }
}
