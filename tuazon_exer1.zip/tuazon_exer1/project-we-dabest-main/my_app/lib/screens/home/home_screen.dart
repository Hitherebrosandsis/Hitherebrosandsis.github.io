import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/app_theme.dart';
import '../../models/item_model.dart';
import '../../widgets/item_card.dart';
import '../item/post_item_screen.dart';
import '../item/item_detail_screen.dart';
import '../profile/profile_screen.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart' hide AuthProvider;
import 'package:my_app/providers/auth_provider.dart';
import '../cart/cart_screen.dart';
import '../notification/notifications_screen.dart';
import 'package:geolocator/geolocator.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String fullName = "Guest";
  Set<String> selectedTags = {};
  double userLatitude = 0;
  double userLongitude = 0;
  double discoveryRadius = 50;

  List<String> userTags = [];

  final Map<String, List<String>> filterCategories = {
    "Dietary": ["Vegan", "Vegetarian", "Halal", "Keto", "Gluten-Free"],
    "Food Type": [
      "Home-Cooked",
      "Raw Ingredients",
      "Cooked Meals",
      "Snacks",
      "Beverages"
    ],
    "Allergens": ["Dairy-Free", "Nut-Free", "Seafood-Free"],
  };

  double calculateDistance({
    required double startLat,
    required double startLng,
    required double endLat,
    required double endLng,
  }) {
    return Geolocator.distanceBetween(
          startLat,
          startLng,
          endLat,
          endLng,
        ) /
        1000;
  }

  Future<void> loadUserPreferences() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) return;

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();

    setState(() {
      userLatitude = (doc['latitude'] ?? 0).toDouble();
      userLongitude = (doc['longitude'] ?? 0).toDouble();
      discoveryRadius = (doc['discoveryRadius'] ?? 50).toDouble();
      userTags = List<String>.from(
        doc['tags'] ?? [],
      );
      selectedTags = Set.from(userTags);
    });
  }

  @override
  void initState() {
    super.initState();
    loadProfile();
    loadUserPreferences();
  }

  Future<void> loadProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();

    if (doc.exists) {
      setState(() {
        fullName = doc['fullName'];
      });
    }
  }

  void _openFilterSheet() {
    Set<String> tempSelected = Set.from(selectedTags);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Handle bar
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Filter Products",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.dark,
                        ),
                      ),
                      if (tempSelected.isNotEmpty)
                        TextButton(
                          onPressed: () {
                            setSheetState(() => tempSelected.clear());
                          },
                          child: const Text(
                            "Clear All",
                            style: TextStyle(color: AppColors.danger),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Filter categories
                  ...filterCategories.entries.map((entry) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          entry.key,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: AppColors.dark,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: entry.value.map((tag) {
                            final isSelected = tempSelected.contains(tag);
                            return GestureDetector(
                              onTap: () {
                                setSheetState(() {
                                  if (isSelected) {
                                    tempSelected.remove(tag);
                                  } else {
                                    tempSelected.add(tag);
                                  }
                                });
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 180),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppColors.accent
                                      : Colors.grey[100],
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: isSelected
                                        ? AppColors.accent
                                        : Colors.grey[300]!,
                                  ),
                                ),
                                child: Text(
                                  tag,
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white
                                        : AppColors.dark,
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.normal,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 16),
                      ],
                    );
                  }),

                  // apply button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        setState(() {
                          selectedTags = Set.from(tempSelected);
                        });
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        tempSelected.isEmpty
                            ? "Show All"
                            : "Apply ${tempSelected.length} Filter${tempSelected.length > 1 ? 's' : ''}",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  bool _itemMatchesFilters(Map<String, dynamic> data) {
    if (selectedTags.isEmpty) return true;
    final List<dynamic> itemTags = data['tags'] ?? [];
    return selectedTags.any((tag) => itemTags.contains(tag));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      appBar: AppBar(
        backgroundColor: AppColors.accent,
        title: const Text(
          "ELBITES",
          style: TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: 4,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ProfileScreen()),
              );
            },
          ),
          // notification icon with unread count badge
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('notifications')
                .where(
                  'userId',
                  isEqualTo: FirebaseAuth.instance.currentUser!.uid,
                )
                .where(
                  'isRead',
                  isEqualTo: false,
                )
                .snapshots(),
            builder: (context, snapshot) {
              final unreadCount = snapshot.data?.docs.length ?? 0;

              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                    },
                  ),
                  if (unreadCount > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          unreadCount > 9 ? "9+" : unreadCount.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final authProvider =
                  Provider.of<AuthProvider>(context, listen: false);
              await authProvider.signOut();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  "Ready to eat, $fullName? 😋",
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppColors.dark,
                  ),
                ),
                const SizedBox(width: 6),
              ],
            ),

            const SizedBox(height: 12),

            // post and listings buttons
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      final user = FirebaseAuth.instance.currentUser;

                      if (user == null) return;

                      if (!context.mounted) return;

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const PostItemScreen(),
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.accent,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.add,
                            color: Colors.white,
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Post Product",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const CartScreen()),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.secondary,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Column(
                        children: [
                          Icon(Icons.inventory),
                          SizedBox(height: 8),
                          Text("My Listings"),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // header + filter button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Nearby Products",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppColors.dark,
                  ),
                ),
                GestureDetector(
                  onTap: _openFilterSheet,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: selectedTags.isNotEmpty
                          ? AppColors.accent
                          : AppColors.secondary.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.tune,
                          size: 16,
                          color: selectedTags.isNotEmpty
                              ? Colors.white
                              : AppColors.accent,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          selectedTags.isEmpty
                              ? "Filter"
                              : "Filter (${selectedTags.length})",
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: selectedTags.isNotEmpty
                                ? Colors.white
                                : AppColors.accent,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Active filter chips
            if (selectedTags.isNotEmpty) ...[
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: selectedTags.map((tag) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: Chip(
                        label: Text(tag,
                            style: const TextStyle(
                                fontSize: 12, color: Colors.white)),
                        backgroundColor: AppColors.accent,
                        deleteIcon: const Icon(Icons.close,
                            size: 14, color: Colors.white),
                        onDeleted: () {
                          setState(() => selectedTags.remove(tag));
                        },
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],

            const SizedBox(height: 10),

            // products
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('items')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return Center(child: Text("Error: ${snapshot.error}"));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No items available"));
                  }

                  final now = DateTime.now();

                  // removes the completed items
                  var docs = snapshot.data!.docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    return data['status'] != 'completed';
                  }).toList();

                  // cleanup invalid transactions
                  for (var doc in docs) {
                    final data = doc.data() as Map<String, dynamic>;

                    if (data['expirationDate'] == null) {
                      continue;
                    }

                    final expiration =
                        (data['expirationDate'] as Timestamp).toDate();

                    final status = data['status'];

                    // for expired items
                    if (expiration.isBefore(now)) {
                      FirebaseFirestore.instance
                          .collection('items')
                          .doc(doc.id)
                          .update({
                        'status': 'completed',
                        'requestedBy': null,
                        'pickupTime': null,
                      });

                      continue;
                    }

                    // for reserved items that reached pickup time but not yet marked completed
                    if (status == 'reserved' && data['pickupTime'] != null) {
                      final pickupTime =
                          (data['pickupTime'] as Timestamp).toDate();

                      // pickup time passed
                      if (pickupTime
                          .add(
                            const Duration(hours: 1),
                          )
                          .isBefore(now)) {
                        // enough time before expiry
                        if (expiration.isAfter(
                          now.add(
                            const Duration(hours: 1),
                          ),
                        )) {
                          FirebaseFirestore.instance
                              .collection('items')
                              .doc(doc.id)
                              .update({
                            'status': 'available',
                            'requestedBy': null,
                            'pickupTime': null,
                          });
                        } else {
                          FirebaseFirestore.instance
                              .collection('items')
                              .doc(doc.id)
                              .update({
                            'status': 'completed',
                            'requestedBy': null,
                            'pickupTime': null,
                          });
                        }
                      }
                    }
                  }

                  // apply radius + tag filters
                  docs = docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;

                    // tag filters
                    final matchesTags = selectedTags.isEmpty
                        ? true
                        : _itemMatchesFilters(
                            data,
                          );

                    // location filters
                    final itemLat = (data['latitude'] ?? 0).toDouble();

                    final itemLng = (data['longitude'] ?? 0).toDouble();

                    // if user or item has no location yet,
                    // don't radius filter
                    if (userLatitude == 0 ||
                        userLongitude == 0 ||
                        itemLat == 0 ||
                        itemLng == 0) {
                      return matchesTags;
                    }

                    final distance = calculateDistance(
                      startLat: userLatitude,
                      startLng: userLongitude,
                      endLat: itemLat,
                      endLng: itemLng,
                    );

                    final withinRadius = distance <= discoveryRadius;

                    return matchesTags && withinRadius;
                  }).toList();

                  if (docs.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.search_off,
                              size: 48, color: Colors.grey[400]),
                          const SizedBox(height: 12),
                          Text(
                            "No items match your filters",
                            style: TextStyle(color: Colors.grey[500]),
                          ),
                          TextButton(
                            onPressed: () =>
                                setState(() => selectedTags.clear()),
                            child: const Text("Clear filters"),
                          ),
                        ],
                      ),
                    );
                  }

                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      final item = ItemModel.fromFirestore(
                        docs[index].data() as Map<String, dynamic>,
                        docs[index].id,
                      );
                      final data = docs[index].data() as Map<String, dynamic>;

                      final itemLat = (data['latitude'] ?? 0).toDouble();

                      final itemLng = (data['longitude'] ?? 0).toDouble();

                      final distance = calculateDistance(
                        startLat: userLatitude,
                        startLng: userLongitude,
                        endLat: itemLat,
                        endLng: itemLng,
                      );

                      return ItemCard(
                        item: item,
                        distanceKm: distance,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ItemDetailScreen(item: item),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
