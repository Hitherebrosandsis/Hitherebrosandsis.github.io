import 'package:flutter/material.dart';
import 'package:my_app/api/firebase_auth_api.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthProvider with ChangeNotifier {
  late FirebaseAuthAPI authService;

  User? userObj;
  bool isLoading = true;
  bool profileCompleted = false;

  AuthProvider() {
    authService = FirebaseAuthAPI();
    fetchAuthentication();
  }

  // Check if profile is completed
  Future<void> checkProfileCompleted() async {
    if (userObj == null) return;

    final doc = await FirebaseFirestore.instance
        .collection("users")
        .doc(userObj!.uid)
        .get();

    profileCompleted = doc.data()?["profileCompleted"] ?? false;

    notifyListeners();
  }

  // Set profile is completed
  Future<void> setProfileCompleted(bool value) async {
    if (userObj == null) return;
    await FirebaseFirestore.instance
        .collection("users")
        .doc(userObj!.uid)
        .update({
      "profileCompleted": value,
    });
    profileCompleted = value;
    notifyListeners();
  }

  void fetchAuthentication() {
    authService.getUser.listen((User? user) async {
      userObj = user;

      if (userObj != null) {
        await checkProfileCompleted();
      } else {
        profileCompleted = false;
      }
      isLoading = false;
      notifyListeners();
    });
  }

  // SIGN UP
  Future<String?> signUp(String email, String password, String fullName) async {
    isLoading = true;
    notifyListeners();

    try {
      final credential = await authService.signUp(email, password, fullName);

      final user = credential.user;

      if (user == null) {
        return 'Failed to create user.';
      }

      userObj = user;
      profileCompleted = false;

      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'fullName': fullName,
        'email': email,
        'tags': [],
        'profileCompleted': false,
        'createdAt': FieldValue.serverTimestamp(),
        'itemAlerts': true,
        'pickupReminders': true,
      });

      return null;
    } catch (e) {
      debugPrint(e.toString());
      return e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<String?> signIn(String email, String password) async {
    isLoading = true;
    notifyListeners();

    try {
      final userCredential = await authService.signIn(email, password);

      userObj = userCredential.user;

      if (userObj != null) {
        await checkProfileCompleted();
      }

      return null;
    } on FirebaseAuthException catch (e) {
      return e.code;
    } catch (e) {
      return "unknown-error";
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> resetPassword(
    BuildContext context,
    String email,
  ) async {
    if (email.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Please enter your email first",
          ),
        ),
      );

      return;
    }

    try {
      final userQuery = await FirebaseFirestore.instance
          .collection('users')
          .where(
            'email',
            isEqualTo: email.trim(),
          )
          .get();

      if (userQuery.docs.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              "No account found for that email",
            ),
          ),
        );

        return;
      }

      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: email.trim(),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Password reset email sent",
          ),
        ),
      );
    } on FirebaseAuthException catch (e) {
      String message = "Something went wrong";

      if (e.code == "invalid-email") {
        message = "Invalid email address";
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
        ),
      );
    }
  }

  Future<void> signOut() async {
    await authService.signOut();
    userObj = null;
    notifyListeners();
  }
}
