import 'package:flutter/material.dart';

class AppColors {
  // Core palette
  static const Color base = Color(0xFFF5F9E9);
  static const Color accent = Color(0xFF4F7CAC);
  static const Color secondary = Color(0xFFC0E0DE);
  static const Color dark = Color(0xFF162521);

  // Text
  static const Color textOnAccent = Colors.white;
  static const Color textOnBase = Colors.black87;

  // Status colors
  static const Color success = Color(0xFF5BAE66);
  static const Color warning = Color(0xFFF2A65A);
  static const Color danger = Color(0xFFD9534F);
  static const Color disabled = Color(0xFFBDBDBD);

  // Card/UI
  static const Color card = Colors.white;
  static const Color border = Color(0xFFE0E0E0);
  static const Color chipBackground = Color(0xFFE8F1F8);
  static const Color subtleText = Color(0xFF6B7280);
}
