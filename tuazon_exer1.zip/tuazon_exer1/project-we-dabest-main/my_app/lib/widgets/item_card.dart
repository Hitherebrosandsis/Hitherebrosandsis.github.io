import 'package:flutter/material.dart';
import 'dart:convert';
import '../models/item_model.dart';
import '../core/app_theme.dart';

Widget _buildImage(String imageUrl,
    {double height = 140, BoxFit fit = BoxFit.cover}) {
  if (imageUrl.isEmpty) {
    return Container(
      height: height,
      width: double.infinity,
      color: Colors.grey[300],
      child: const Center(child: Icon(Icons.image)),
    );
  }
  try {
    final bytes = base64Decode(imageUrl);
    return Image.memory(
      bytes,
      height: height,
      width: double.infinity,
      fit: fit,
      errorBuilder: (_, __, ___) => Container(
        height: height,
        color: Colors.grey[300],
        child: const Center(child: Icon(Icons.broken_image)),
      ),
    );
  } catch (_) {
    return Container(
      height: height,
      color: Colors.grey[300],
      child: const Center(child: Icon(Icons.broken_image)),
    );
  }
}

class ItemCard extends StatelessWidget {
  final ItemModel item;
  final VoidCallback onTap;
  final double? distanceKm;

  const ItemCard({
    super.key,
    required this.item,
    required this.onTap,
    this.distanceKm,
  });

  @override
  Widget build(BuildContext context) {
    final isExpired = item.expirationDate.isBefore(DateTime.now());

    return GestureDetector(
      onTap: isExpired ? null : onTap,
      child: Stack(
        children: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: isExpired ? Colors.grey[300] : Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 6,
                  offset: const Offset(0, 3),
                )
              ],
            ),
            child: Opacity(
              opacity: isExpired ? 0.6 : 1.0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Image
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                    child: _buildImage(item.imageUrl),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: AppColors.dark,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: AppColors.dark.withOpacity(0.6),
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 8),

                        // Location label
                        if (item.locationName != null &&
                            item.locationName!.isNotEmpty)
                          Row(
                            children: [
                              const Icon(Icons.location_on,
                                  size: 12, color: Colors.grey),
                              const SizedBox(width: 3),
                              Expanded(
                                child: Text(
                                  item.locationName!,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ],
                          ),

                        const SizedBox(height: 6),

                        if (item.tags.isNotEmpty)
                          Wrap(
                            spacing: 4,
                            children: item.tags.take(3).map((tag) {
                              return Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.secondary,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  tag,
                                  style: const TextStyle(fontSize: 10),
                                ),
                              );
                            }).toList(),
                          ),
                        if (item.tags.length > 3)
                          Text(
                            "+${item.tags.length - 3} more",
                            style: const TextStyle(
                                fontSize: 10, color: Colors.grey),
                          ),

                        const SizedBox(height: 6),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.ownerName,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: AppColors.dark.withOpacity(0.5),
                                  ),
                                ),
                                if (distanceKm != null)
                                  Text(
                                    distanceKm! < 1
                                        ? "${(distanceKm! * 1000).toInt()} m away"
                                        : "${distanceKm!.toStringAsFixed(1)} km away",
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: isExpired
                                    ? Colors.red.withOpacity(0.2)
                                    : item.status == 'available'
                                        ? AppColors.success.withOpacity(0.2)
                                        : AppColors.warning.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                isExpired ? "expired" : item.status,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: isExpired
                                      ? AppColors.danger
                                      : item.status == 'available'
                                          ? AppColors.success
                                          : item.status == 'completed'
                                              ? AppColors.danger
                                              : AppColors.warning,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isExpired)
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  "EXPIRED",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
