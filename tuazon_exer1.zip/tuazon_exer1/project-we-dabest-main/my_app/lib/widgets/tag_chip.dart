import 'package:flutter/material.dart';
import '../core/app_theme.dart';

class TagChip extends StatelessWidget {
  final String label;
  final bool selected;
  final Function(bool) onSelected;

  const TagChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return FilterChip(
      label: Text(label),
      selected: selected,
      selectedColor: AppColors.secondary,
      checkmarkColor: AppColors.dark,
      onSelected: onSelected,
    );
  }
}
